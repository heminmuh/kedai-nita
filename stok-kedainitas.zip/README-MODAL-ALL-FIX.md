# Perbaikan semua modal — Kedai Nita’s

Semua formulir modal memakai struktur tampilan konsisten: header tetap, konten scroll mandiri, footer aksi tetap. Berlaku pada master Barang/Supplier/Rak, tambah/edit pengguna, inbound, outbound, pengajuan dan peninjauan opname, serta retur barang.

Tidak mengubah server action, validasi, maupun aturan database.

## Instalasi
Salin proyek ini ke folder kerja (simpan .env.local milik sendiri, tidak disertakan), lalu jalankan `npm install` dan `npm run build`.

Catatan: build belum diverifikasi di lingkungan ini.
