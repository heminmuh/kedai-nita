import { cache } from 'react';
import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import type { Profile } from '@/lib/types';
import { isOwner } from '@/lib/auth-roles';

export { isOwner } from '@/lib/auth-roles';

/**
 * Supabase Auth sudah menerbitkan JWT. getClaims() memverifikasi token (lokal
 * menggunakan JWKS bila proyek memakai asymmetric signing key), sehingga
 * tidak selalu perlu request Auth API seperti getUser().
 * cache() hanya deduplikasi per server-render/request, BUKAN cache lintas user.
 */
export const getActor = cache(async () => {
  const supabase = await createClient();
  const { data: claimsData, error: claimsError } = await supabase.auth.getClaims();
  const userId = claimsData?.claims?.sub;
  if (claimsError || !userId) throw new Error('Sesi berakhir. Silakan login.');

  // Jangan ambil peran dari JWT: cek profil aktif langsung ke DB agar
  // perubahan izin/penonaktifan akun berlaku pada request berikutnya.
  const { data, error } = await supabase
    .from('pengguna')
    .select('*')
    .eq('auth_id', userId)
    .eq('aktif', true)
    .single();
  if (error || !data) throw new Error('Akun belum terdaftar/aktif.');

  return { supabase, user: { id: userId }, profile: data as Profile };
});

export async function requireOwner(message = 'Hanya owner yang dapat melakukan ini') {
  const actor = await getActor();
  if (!isOwner(actor.profile)) throw new Error(message);
  return actor;
}

export async function requireOwnerPage() {
  const actor = await getActor();
  if (!isOwner(actor.profile)) redirect('/dashboard');
  return actor;
}
