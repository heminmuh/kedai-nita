import { cache } from 'react';
import { createClient } from '@/lib/supabase/server';
import type { ProductOption, Row, SupplierOption } from '@/lib/types';

/** Ambil baris dari sebuah tabel (RLS Supabase yang menentukan akses). */
export const fetchRows = cache(async (table: string, columns = '*', limit = 100): Promise<Row[]> => {
  const supabase = await createClient();
  const { data, error } = await supabase.from(table).select(columns).limit(limit);
  if (error) throw new Error(error.message);
  return (data ?? []) as unknown as Row[];
});

export async function fetchProductOptions(): Promise<ProductOption[]> {
  const rows = await fetchRows('barang');
  return rows.map((x) => ({
    id_barang: Number(x.id_barang),
    nama_barang: String(x.nama_barang),
    stok_saat_ini: Number(x.stok_saat_ini),
  }));
}

export async function fetchSupplierOptions(): Promise<SupplierOption[]> {
  const rows = await fetchRows('supplier');
  return rows.map((x) => ({
    id_supplier: Number(x.id_supplier),
    nama_supplier: String(x.nama_supplier),
  }));
}
