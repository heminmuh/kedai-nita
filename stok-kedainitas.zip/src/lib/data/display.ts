﻿import { createClient } from '@/lib/supabase/server';
import type { Row } from '@/lib/types';
import { fetchRows } from './queries';

/** Rows enriched for human-friendly tables, without exposing database IDs. */
export async function fetchRackDisplay(): Promise<Row[]> {
  const [racks, products] = await Promise.all([fetchRows('lokasi_rak'), fetchRows('barang')]);
  return racks.map(rack => {
    const items = products.filter(p => String(p.id_rak ?? '') === String(rack.id_rak));
    return {
      ...rack,
      isi_rak: items.length ? items.map(p => `${p.nama_barang} (${Number(p.stok_saat_ini ?? 0).toLocaleString('id-ID')} ${p.satuan ?? ''})`).join(' â€¢ ') : 'Belum ada barang',
      jumlah_jenis_barang: items.length,
    };
  });
}

export async function fetchTransactionDisplay(kind: 'inbound' | 'outbound'): Promise<Row[]> {
  const [headers, products, suppliers] = await Promise.all([
    fetchRows(kind), fetchRows('barang'), kind === 'inbound' ? fetchRows('supplier') : Promise.resolve([] as Row[]),
  ]);
  const supabase = await createClient();
  const ids = headers.map(h => Number(h[kind === 'inbound' ? 'id_inbound' : 'id_outbound']));
  if (!ids.length) return [];
  const detailTable = kind === 'inbound' ? 'inbound_detail' : 'outbound_detail';
  const foreignKey = kind === 'inbound' ? 'id_inbound' : 'id_outbound';
  const { data, error } = await supabase.from(detailTable).select(`${foreignKey},id_barang,jumlah`).in(foreignKey, ids);
  if (error) throw new Error(error.message);
  const productNames = new Map(products.map(p => [String(p.id_barang), `${p.nama_barang} (${p.satuan ?? 'unit'})`]));
  const supplierNames = new Map(suppliers.map(s => [String(s.id_supplier), String(s.nama_supplier)]));
  const paths = headers.map(h => h.foto_nota).filter((v): v is string => typeof v === 'string' && !!v);
  const photoUrls = new Map<string,string>();
  await Promise.all(paths.map(async path => {
    const { data: signed, error: signedError } = await supabase.storage.from('nota').createSignedUrl(path, 60 * 15);
    if (!signedError && signed?.signedUrl) photoUrls.set(path, signed.signedUrl);
  }));
  return headers.map(h => {
    const key = String(h[foreignKey]);
    const details = (data ?? []).filter(d => String('id_inbound' in d && foreignKey === 'id_inbound' ? d.id_inbound : 'id_outbound' in d && foreignKey === 'id_outbound' ? d.id_outbound : '') === key);
    const itemText = details.map(d => `${productNames.get(String(d.id_barang)) ?? 'Barang tidak ditemukan'} Ã— ${Number(d.jumlah).toLocaleString('id-ID')}`).join(' â€¢ ');
    return {
      ...h,
      nama_supplier: kind === 'inbound' ? (supplierNames.get(String(h.id_supplier)) ?? 'Tanpa supplier') : undefined,
      daftar_barang: itemText || 'Tidak ada rincian',
      total_jenis_barang: details.length,
      foto_url: typeof h.foto_nota === 'string' ? (photoUrls.get(h.foto_nota) ?? null) : null,
    };
  });
}

export async function fetchStockCardDisplay(): Promise<Row[]> {
  const [cards, products, people, opname] = await Promise.all([
    fetchRows('kartu_stok', '*', 1000), fetchRows('barang', '*', 1000),
    fetchRows('pengguna', '*', 1000), fetchRows('stock_opname', '*', 1000),
  ]);
  const names = new Map(products.map(p => [String(p.id_barang), String(p.nama_barang)]));
  const peopleNames = new Map(people.map(p => [String(p.id_pengguna), String(p.nama_lengkap)]));
  const opnameByRef = new Map(opname.map(o => [String(o.no_transaksi ?? ''), o]));
  return cards.sort((a,b) => String(b.waktu ?? '').localeCompare(String(a.waktu ?? ''))).map(card => {
    const kind = String(card.jenis ?? '');
    const approver = peopleNames.get(String(card.id_pengguna)) ?? 'Pengguna tidak ditemukan';
    const relatedOpname = kind === 'adjustment' ? opnameByRef.get(String(card.referensi ?? '')) : undefined;
    const applicant = relatedOpname ? peopleNames.get(String(relatedOpname.id_pengguna)) : undefined;
    const when = String(card.waktu ?? '');
    return {
      ...card,
      jenis_asli: kind,
      jenis: kind === 'adjustment' ? 'Stock Opname' : kind === 'masuk' ? 'Barang Masuk' : kind === 'keluar' && String(card.referensi ?? '').startsWith('RET-') ? 'Retur Barang' : kind === 'keluar' ? 'Barang Keluar' : kind,
      waktu_tampil: when ? new Date(when).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', dateStyle: 'medium', timeStyle: 'short' }) : 'â€”',
      nama_barang: names.get(String(card.id_barang)) ?? 'Barang tidak ditemukan',
      nama_petugas: applicant ?? approver,
      nama_pencatat: approver,
    };
  });
}

export async function fetchOpnameDisplay(): Promise<Row[]> {
  const [headers, products, people] = await Promise.all([fetchRows('stock_opname'), fetchRows('barang'), fetchRows('pengguna')]);
  const ids = headers.map(h => Number(h.id_opname));
  if (!ids.length) return [];
  const supabase = await createClient();
  const { data, error } = await supabase.from('stock_opname_detail').select('id_opname,id_barang,stok_sistem,stok_fisik,selisih').in('id_opname', ids);
  if (error) throw new Error(error.message);
  const names = new Map(products.map(p => [String(p.id_barang), String(p.nama_barang)]));
  const peopleNames = new Map(people.map(p => [String(p.id_pengguna), String(p.nama_lengkap)]));
  const photoPaths = Array.from(new Set(headers.map(h => h.foto_bukti).filter((v): v is string => typeof v === 'string' && !!v)));
  const photoUrls = new Map<string, string>();
  await Promise.all(photoPaths.map(async path => {
    const { data: signed, error: photoError } = await supabase.storage.from('nota').createSignedUrl(path, 60 * 15);
    if (!photoError && signed?.signedUrl) photoUrls.set(path, signed.signedUrl);
  }));
  return headers.map(h => ({ ...h, foto_url: typeof h.foto_bukti === 'string' ? photoUrls.get(h.foto_bukti) ?? null : null, diajukan_oleh: peopleNames.get(String(h.id_pengguna)) ?? 'Pengguna tidak ditemukan', barang_diperiksa: (data ?? []).filter(d => String(d.id_opname) === String(h.id_opname)).map(d => `${names.get(String(d.id_barang)) ?? 'Barang'}: ${d.stok_sistem} â†’ ${d.stok_fisik} (selisih ${d.selisih})`).join(' â€¢ ') || 'â€”' }));
}

export async function fetchStockDisplay(): Promise<Row[]> {
  const [products, racks] = await Promise.all([fetchRows('barang'), fetchRows('lokasi_rak')]);
  const rackNames = new Map(racks.map(r => [String(r.id_rak), String(r.nama_rak)]));
  return products.map(p => ({ ...p, lokasi_rak: rackNames.get(String(p.id_rak)) ?? 'Belum ditempatkan', status_stok: Number(p.stok_saat_ini ?? 0) <= Number(p.stok_minimum ?? 0) ? 'Menipis' : 'Aman' }));
}

