export type Role = 'admin' | 'petugas';

export type Row = Record<string, unknown>;

export interface Profile {
  id_pengguna: number;
  auth_id: string;
  nama_lengkap: string;
  username: string;
  peran: Role;
  aktif: boolean;
  dibuat_pada: string;
}

export interface ProductOption {
  id_barang: number;
  nama_barang: string;
  stok_saat_ini: number;
}

export interface SupplierOption {
  id_supplier: number;
  nama_supplier: string;
}

export type TransactionKind = 'inbound' | 'outbound' | 'opname';
