/** Daftar tanggal (YYYY-MM-DD, UTC) untuk n hari terakhir, termasuk hari ini. */
export function lastDays(n: number): string[] {
  return Array.from({ length: n }, (_, i) => {
    const d = new Date();
    d.setUTCDate(d.getUTCDate() - (n - 1) + i);
    return d.toISOString().slice(0, 10);
  });
}
