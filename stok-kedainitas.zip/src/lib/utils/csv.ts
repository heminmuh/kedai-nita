const BOM = '\uFEFF';

const escapeCell = (value: unknown) => `"${String(value ?? '').replaceAll('"', '""')}"`;

/** Ubah baris data menjadi CSV (UTF-8 BOM, CRLF) agar nyaman dibuka di Excel. */
export function toCsv(columns: string[], rows: Record<string, unknown>[]) {
  const lines = [
    columns.join(','),
    ...rows.map((row) => columns.map((c) => escapeCell(row[c])).join(',')),
  ];
  return BOM + lines.join('\r\n');
}
