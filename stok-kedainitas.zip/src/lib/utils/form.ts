/** Ambil nilai string dari FormData (trim, kosong jika tidak ada). */
export const str = (f: FormData, key: string) => String(f.get(key) ?? '').trim();

/** Ambil nilai angka dari FormData; melempar error jika bukan angka valid. */
export const num = (f: FormData, key: string) => {
  const n = Number(f.get(key));
  if (!Number.isFinite(n)) throw new Error('Angka tidak valid');
  return n;
};
