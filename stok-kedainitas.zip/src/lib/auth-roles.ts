import type { Profile } from '@/lib/types';

/** Pure role check, safe to import from Server and Client Components. */
export const isOwner = (profile: Profile) => profile.peran === 'admin';
