'use server';

import { revalidatePath } from 'next/cache';
import { getActor, requireOwner } from '@/lib/auth';
import { num, str } from '@/lib/utils/form';

export async function submitInbound(f: FormData) {
  if (!str(f, 'foto_nota')) throw new Error('Foto bukti barang masuk wajib diunggah.');
  const { supabase } = await getActor();
  const { error } = await supabase.rpc('create_inbound', {
    p_supplier: str(f, 'id_supplier') ? num(f, 'id_supplier') : null,
    p_catatan: str(f, 'catatan'),
    p_items: JSON.parse(str(f, 'items')),
    p_foto_nota: str(f, 'foto_nota') || null,
  });
  if (error) throw new Error(error.message);
  revalidatePath('/inbound');
  revalidatePath('/stok');
}

export async function submitOutbound(f: FormData) {
  if (!str(f, 'foto_nota')) throw new Error('Foto bukti barang keluar wajib diunggah.');
  const { supabase } = await getActor();
  const { error } = await supabase.rpc('create_outbound', {
    p_tujuan: str(f, 'tujuan'),
    p_catatan: str(f, 'catatan'),
    p_items: JSON.parse(str(f, 'items')),
    p_foto_nota: str(f, 'foto_nota') || null,
  });
  if (error) throw new Error(error.message);
  revalidatePath('/outbound');
  revalidatePath('/stok');
}

export async function submitOpname(f: FormData) {
  if (!str(f, 'foto_nota')) throw new Error('Foto bukti stock opname wajib diunggah.');
  const { supabase, profile } = await getActor();
  if (profile.peran !== 'petugas') throw new Error('Hanya petugas yang dapat mengajukan opname.');
  const { error } = await supabase.rpc('create_opname', {
    p_catatan: str(f, 'catatan'),
    p_items: JSON.parse(str(f, 'items')),
    p_foto_bukti: str(f, 'foto_nota') || null,
  });
  if (error) throw new Error(error.message);
  revalidatePath('/opname');
}

export async function reviewOpname(f: FormData) {
  const { supabase } = await requireOwner('Hanya admin yang dapat meninjau opname.');
  if (str(f, 'note').trim().length < 3) throw new Error('Alasan keputusan wajib diisi (minimal 3 karakter).');
  if (!['approve','reject'].includes(str(f, 'decision'))) throw new Error('Keputusan tidak valid.');
  const { error } = await supabase.rpc('review_opname', {
    p_id: num(f, 'id'),
    p_approve: str(f, 'decision') === 'approve',
    p_note: str(f, 'note'),
  });
  if (error) throw new Error(error.message);
  revalidatePath('/opname');
  // Approval menyesuaikan barang dan menambahkan transaksi adjustment ke kartu stok.
  revalidatePath('/stok');
  revalidatePath('/kartu-stok');
  revalidatePath('/dashboard');
  revalidatePath('/laporan');
}
