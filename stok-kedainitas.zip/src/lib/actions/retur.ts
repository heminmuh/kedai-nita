'use server';
import { revalidatePath } from 'next/cache';
import { getActor } from '@/lib/auth';

export async function createSupplierReturn(form: FormData) {
  const {supabase} = await getActor();
  const supplier = Number(form.get('id_supplier'));
  const reason = String(form.get('alasan') ?? '').trim();
  const items = JSON.parse(String(form.get('items') ?? '[]'));
  const photo = String(form.get('foto_bukti') ?? '').trim();
  if (!photo) throw new Error('Foto bukti retur wajib diunggah.');
  if (!Number.isSafeInteger(supplier) || supplier<1) throw new Error('Pilih supplier');
  if (reason.length<3) throw new Error('Alasan retur minimal 3 karakter');
  if (!Array.isArray(items) || items.length===0 || items.some(i => !Number.isSafeInteger(i.id_barang) || !(i.jumlah>0))) throw new Error('Isi barang dan jumlah retur');
  const {error} = await supabase.rpc('create_retur_supplier',{p_supplier:supplier,p_alasan:reason,p_items:items,p_foto_bukti:photo});
  if(error) throw new Error(error.message);
  for (const path of ['/retur','/stok','/kartu-stok','/dashboard','/laporan']) revalidatePath(path);
}
