'use server';

import { getActor } from '@/lib/auth';

const MAX_SIZE = 2 * 1024 * 1024;
const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp'];

/** Upload foto nota ke bucket privat `nota`; mengembalikan path file. */
export async function uploadNota(f: FormData) {
  const { supabase } = await getActor();
  const file = f.get('file');

  if (!(file instanceof File) || file.size > MAX_SIZE || !ALLOWED_TYPES.includes(file.type)) {
    throw new Error('File harus JPG/PNG/WebP maksimal 2MB');
  }

  const safeName = file.name.replace(/[^a-zA-Z0-9.\-_]/g, '_');
  const path = `${crypto.randomUUID()}-${safeName}`;

  const { error } = await supabase.storage.from('nota').upload(path, file, {
    contentType: file.type,
  });
  if (error) throw new Error(error.message);
  return path;
}
