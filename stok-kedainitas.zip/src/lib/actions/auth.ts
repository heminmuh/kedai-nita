'use server';

import { createClient as createAdminClient } from '@supabase/supabase-js';
import { createClient } from '@/lib/supabase/server';
import { getSupabaseEnv } from '@/lib/supabase/env';
import { str } from '@/lib/utils/form';

const LOGIN_ERROR = 'Username atau kata sandi salah, atau akun tidak aktif.';

export async function login(f: FormData) {
  const username = str(f, 'username').toLowerCase();
  const password = str(f, 'password');
  if (!/^[a-z0-9._-]{3,32}$/.test(username) || !password) {
    throw new Error(LOGIN_ERROR);
  }

  // Pemetaan username -> email hanya berlangsung di server. Service role
  // tidak dikirim ke browser dan tidak digunakan sebagai sesi login.
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!serviceKey) throw new Error('Konfigurasi server belum lengkap. Hubungi administrator.');
  const { url } = getSupabaseEnv();
  const admin = createAdminClient(url, serviceKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });

  const { data: profile, error: lookupError } = await admin
    .from('pengguna')
    .select('auth_id, aktif')
    .eq('username', username)
    .maybeSingle();
  if (lookupError) throw new Error('Gagal menghubungi layanan login. Coba lagi.');
  if (!profile?.auth_id || !profile.aktif) throw new Error(LOGIN_ERROR);

  const { data: account, error: accountError } = await admin.auth.admin.getUserById(profile.auth_id);
  if (accountError || !account?.user?.email) throw new Error(LOGIN_ERROR);

  const supabase = await createClient();
  const { data: signedIn, error: signInError } = await supabase.auth.signInWithPassword({
    email: account.user.email,
    password,
  });
  if (signInError || signedIn.user?.id !== profile.auth_id) {
    if (signedIn.session) await supabase.auth.signOut();
    throw new Error(LOGIN_ERROR);
  }
  return { ok: true as const };
}

export async function logout() {
  const supabase = await createClient();
  const { error } = await supabase.auth.signOut();
  if (error) throw new Error('Gagal keluar dari akun. Coba lagi.');
  return { ok: true as const };
}
