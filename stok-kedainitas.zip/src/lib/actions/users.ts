'use server';

import { revalidatePath } from 'next/cache';
import { requireOwner } from '@/lib/auth';
import { num, str } from '@/lib/utils/form';
import { createClient as createAdminClient } from '@supabase/supabase-js';
import { getSupabaseEnv } from '@/lib/supabase/env';

export async function updateProfile(f: FormData) {
  const { supabase } = await requireOwner('Owner saja');
  const { error } = await supabase
    .from('pengguna')
    .update({
      nama_lengkap: str(f, 'nama_lengkap'),
      peran: str(f, 'peran'),
      aktif: str(f, 'aktif') === 'true',
    })
    .eq('id_pengguna', num(f, 'id_pengguna'));
  if (error) throw new Error(error.message);
  revalidatePath('/pengguna');
}

/** Called only from the server. Never expose the service role key to client code. */
export async function createWarehouseUser(form: FormData) {
  await requireOwner('Hanya admin yang dapat menambah pengguna.');

  const name = str(form, 'nama_lengkap').trim();
  const username = str(form, 'username').trim().toLowerCase();
  const email = str(form, 'email').trim().toLowerCase();
  const password = str(form, 'password');
  const role = str(form, 'peran');
  const active = str(form, 'aktif') === 'true';

  if (name.length < 2 || name.length > 100) throw new Error('Nama harus 2–100 karakter.');
  if (!/^[a-z0-9._-]{3,32}$/.test(username)) throw new Error('Username harus 3–32 karakter: huruf kecil, angka, titik, _ atau -.');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error('Email tidak valid.');
  if (password.length < 8 || password.length > 128) throw new Error('Password harus 8–128 karakter.');
  if (role !== 'admin' && role !== 'petugas') throw new Error('Peran tidak valid.');
  if (!['true', 'false'].includes(str(form, 'aktif'))) throw new Error('Status tidak valid.');

  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!serviceKey) throw new Error('SUPABASE_SERVICE_ROLE_KEY belum dikonfigurasi di server.');
  const { url } = getSupabaseEnv();
  const admin = createAdminClient(url, serviceKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });

  const { data: existing, error: lookupError } = await admin.from('pengguna')
    .select('id_pengguna').eq('username', username).maybeSingle();
  if (lookupError) throw new Error('Gagal memeriksa username.');
  if (existing) throw new Error('Username sudah digunakan.');

  // Admin API does not log out or replace the current admin's session.
  const { data: created, error: authError } = await admin.auth.admin.createUser({
    email, password, email_confirm: true,
  });
  if (authError || !created.user) throw new Error(authError?.message ?? 'Gagal membuat akun Auth.');

  const { error: profileError } = await admin.from('pengguna').insert({
    auth_id: created.user.id,
    nama_lengkap: name,
    username,
    peran: role,
    aktif: active,
  });
  if (profileError) {
    const { error: rollbackError } = await admin.auth.admin.deleteUser(created.user.id);
    if (rollbackError) throw new Error('Profil gagal dibuat dan rollback akun Auth gagal. Hubungi administrator untuk memeriksa akun terkait.');
    throw new Error(`Gagal membuat profil: ${profileError.message}`);
  }
  revalidatePath('/pengguna');
}
