'use server';

import { revalidatePath } from 'next/cache';
import { requireOwner } from '@/lib/auth';
import { isMasterSlug, MASTER_CONFIG, type MasterField } from '@/lib/config/master';
import { str } from '@/lib/utils/form';

function parseField(f: FormData, field: MasterField) {
  const raw = str(f, field.name);
  switch (field.kind) {
    case 'number':
      return Number(raw || 0);
    case 'ref':
      return raw ? Number(raw) : null;
    default:
      return raw || null;
  }
}

/** Tambah (atau ubah, bila `id` dikirim) data master barang/supplier/rak. */
export async function saveMaster(f: FormData) {
  const { supabase } = await requireOwner('Hanya admin yang dapat mengelola master data.');

  const slug = str(f, 'slug');
  if (!isMasterSlug(slug)) throw new Error('Modul tidak valid');
  const cfg = MASTER_CONFIG[slug];

  const values = Object.fromEntries(cfg.fields.map((field) => [field.name, parseField(f, field)]));
  const id = str(f, 'id');

  const { error } = id
    ? await supabase.from(cfg.table).update(values).eq(cfg.idKey, Number(id))
    : await supabase.from(cfg.table).insert(values);
  if (error) throw new Error(error.message);

  revalidatePath(cfg.path);
}


/** Hapus master yang belum digunakan oleh data lain. Relasi transaksi tetap terlindungi. */
export async function deleteMaster(form: FormData) {
  const { supabase } = await requireOwner('Hanya admin yang dapat mengelola master data.');
  const slug = str(form, 'slug');
  if (!isMasterSlug(slug)) throw new Error('Modul tidak valid.');
  const cfg = MASTER_CONFIG[slug];
  const id = Number(str(form, 'id'));
  if (!Number.isSafeInteger(id) || id < 1) throw new Error('ID data tidak valid.');

  const checks: { table: string; column: string; label: string }[] = slug === 'rak'
    ? [{table:'barang', column:'id_rak', label:'barang yang masih ditempatkan di rak'}]
    : slug === 'supplier'
    ? [{table:'barang', column:'id_supplier_utama', label:'barang dengan supplier utama ini'},
       {table:'inbound', column:'id_supplier', label:'riwayat barang masuk'}]
    : [{table:'inbound_detail', column:'id_barang', label:'riwayat barang masuk'},
       {table:'outbound_detail', column:'id_barang', label:'riwayat barang keluar'},
       {table:'stock_opname_detail', column:'id_barang', label:'riwayat stock opname'},
       {table:'kartu_stok', column:'id_barang', label:'riwayat kartu stok'}];

  for (const check of checks) {
    const { count, error } = await supabase.from(check.table)
      .select('*', { count: 'exact', head: true }).eq(check.column, id);
    if (error) throw new Error(`Gagal memeriksa relasi: ${error.message}`);
    if (count && count > 0) {
      throw new Error(slug === 'rak'
        ? 'Rak masih berisi barang. Pindahkan semua barang ke rak lain atau kosongkan penempatan rak sebelum menghapus.'
        : `Data tidak dapat dihapus karena masih digunakan oleh ${check.label}. Ubah relasi atau pertahankan data untuk menjaga riwayat.`);
    }
  }
  const { error } = await supabase.from(cfg.table).delete().eq(cfg.idKey, id);
  if (error) throw new Error(`Gagal menghapus: ${error.message}`);
  revalidatePath(cfg.path);
  if (slug !== 'rak') revalidatePath('/stok');
}
