import { createServerClient } from '@supabase/ssr';
import { NextResponse, type NextRequest } from 'next/server';
import type { CookieToSet } from './cookies';
import { getSupabaseEnv } from './env';

/** JWT verification + Supabase session refresh when necessary. */
export async function updateSession(req: NextRequest) {
  let response = NextResponse.next({ request: req });
  const { url, anonKey } = getSupabaseEnv();

  const supabase = createServerClient(url, anonKey, {
    cookies: {
      getAll: () => req.cookies.getAll(),
      setAll(items: CookieToSet[]) {
        items.forEach(({ name, value }) => req.cookies.set(name, value));
        response = NextResponse.next({ request: req });
        items.forEach(({ name, value, options }) => response.cookies.set(name, value, options));
      },
    },
  });

  const { data, error } = await supabase.auth.getClaims();
  return { response, authenticated: !error && Boolean(data?.claims?.sub) };
}
