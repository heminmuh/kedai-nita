import { createServerClient } from '@supabase/ssr';
import { cookies } from 'next/headers';
import type { CookieToSet } from './cookies';
import { getSupabaseEnv } from './env';

/** Supabase client untuk Server Components, Server Actions, dan Route Handlers. */
export async function createClient() {
  const jar = await cookies();
  const { url, anonKey } = getSupabaseEnv();

  return createServerClient(url, anonKey, {
    cookies: {
      getAll: () => jar.getAll(),
      setAll(items: CookieToSet[]) {
        try {
          items.forEach(({ name, value, options }) => jar.set(name, value, options));
        } catch {
          // Dipanggil dari Server Component (cookies read-only): aman diabaikan,
          // sesi sudah di-refresh oleh middleware.
        }
      },
    },
  });
}
