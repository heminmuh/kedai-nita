'use client';

import Swal from 'sweetalert2';

const options = { confirmButtonColor: '#6834A6', cancelButtonColor: '#9872D5' };
export async function successAlert(title = 'Berhasil disimpan') {
  await Swal.fire({ ...options, icon: 'success', title, text: 'Perubahan berhasil diproses.', timer: 1700, showConfirmButton: false });
}
export async function errorAlert(error: unknown, title = 'Terjadi kesalahan') {
  const message = error instanceof Error ? error.message : 'Silakan coba kembali.';
  await Swal.fire({ ...options, icon: 'error', title, text: message, confirmButtonText: 'Mengerti' });
}
export async function confirmAlert(title: string, text: string, confirmButtonText = 'Ya, lanjutkan') {
  const result = await Swal.fire({ ...options, icon: 'question', title, text, showCancelButton: true, confirmButtonText, cancelButtonText: 'Batal', reverseButtons: true });
  return result.isConfirmed;
}
