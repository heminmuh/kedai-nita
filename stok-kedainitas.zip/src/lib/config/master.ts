/**
 * Satu sumber kebenaran untuk master data (barang, supplier, rak):
 * dipakai oleh halaman, form, dan server action.
 */
export type FieldKind = 'text' | 'number' | 'ref';

export interface MasterField {
  name: string;
  kind: FieldKind; // 'ref' = angka opsional (foreign key, boleh kosong)
  required?: boolean;
}

export interface MasterConfig {
  title: string;
  table: string;
  idKey: string;
  path: string;
  columns: string[];
  fields: MasterField[];
}

export const MASTER_CONFIG = {
  barang: {
    title: 'Master Barang',
    table: 'barang',
    idKey: 'id_barang',
    path: '/barang',
    columns: ['kode_barang', 'nama_barang', 'kategori', 'satuan', 'lokasi_rak', 'stok_minimum'],
    fields: [
      { name: 'kode_barang', kind: 'text', required: true },
      { name: 'nama_barang', kind: 'text', required: true },
      { name: 'kategori', kind: 'text' },
      { name: 'satuan', kind: 'text', required: true },
      { name: 'stok_minimum', kind: 'number' },
      { name: 'harga_beli_terakhir', kind: 'number' },
      { name: 'id_rak', kind: 'ref' },
      { name: 'id_supplier_utama', kind: 'ref' },
    ],
  },
  supplier: {
    title: 'Supplier',
    table: 'supplier',
    idKey: 'id_supplier',
    path: '/supplier',
    columns: ['nama_supplier', 'kontak', 'telepon', 'alamat'],
    fields: [
      { name: 'nama_supplier', kind: 'text', required: true },
      { name: 'kontak', kind: 'text' },
      { name: 'telepon', kind: 'text' },
      { name: 'alamat', kind: 'text' },
    ],
  },
  rak: {
    title: 'Lokasi Rak',
    table: 'lokasi_rak',
    idKey: 'id_rak',
    path: '/rak',
    columns: ['kode_rak', 'nama_rak', 'isi_rak', 'jumlah_jenis_barang', 'keterangan'],
    fields: [
      { name: 'kode_rak', kind: 'text', required: true },
      { name: 'nama_rak', kind: 'text', required: true },
      { name: 'jenis', kind: 'text' },
      { name: 'keterangan', kind: 'text' },
    ],
  },
} as const satisfies Record<string, MasterConfig>;

export type MasterSlug = keyof typeof MASTER_CONFIG;

export const isMasterSlug = (v: string): v is MasterSlug => v in MASTER_CONFIG;
