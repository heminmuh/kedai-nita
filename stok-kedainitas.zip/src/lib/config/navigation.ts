export interface NavItem {
  href: string;
  label: string;
  ownerOnly?: boolean;
}

export const NAV_ITEMS: NavItem[] = [
  { href: '/dashboard', label: 'Overview' },
  { href: '/barang', label: 'Barang', ownerOnly: true },
  { href: '/supplier', label: 'Supplier', ownerOnly: true },
  { href: '/rak', label: 'Lokasi Rak', ownerOnly: true },
  { href: '/inbound', label: 'Barang Masuk' },
  { href: '/outbound', label: 'Barang Keluar' },
  { href: '/retur', label: 'Retur Barang' },
  { href: '/stok', label: 'Monitoring Stok' },
  { href: '/opname', label: 'Stock Opname' },
  { href: '/kartu-stok', label: 'Kartu Stok' },
  { href: '/laporan', label: 'Laporan', ownerOnly: true },
  { href: '/pengguna', label: 'Pengguna', ownerOnly: true },
];
