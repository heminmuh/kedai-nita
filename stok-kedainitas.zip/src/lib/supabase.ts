﻿import type { CookieOptions } from '@supabase/ssr';
import {createServerClient} from '@supabase/ssr';import {cookies} from 'next/headers';
export async function db(){const jar=await cookies();return createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!,process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,{cookies:{getAll(){return jar.getAll()},setAll(items: { name: string; value: string; options?: CookieOptions }[]){try{items.forEach(({name,value,options})=>jar.set(name,value,options))}catch{}}}})}
export async function actor(){const s=await db();const {data:{user}}=await s.auth.getUser();if(!user)throw new Error('Sesi berakhir. Silakan login.');const {data:profile,error}=await s.from('pengguna').select('*').eq('auth_id',user.id).eq('aktif',true).single();if(error||!profile)throw new Error('Akun belum terdaftar/aktif.');return {s,user,profile}}

