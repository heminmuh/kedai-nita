import { NextResponse, type NextRequest } from 'next/server';
import { updateSession } from '@/lib/supabase/middleware';

export async function middleware(req: NextRequest) {
  const { response, authenticated } = await updateSession(req);
  const { pathname } = req.nextUrl;

  const destination = !authenticated && !pathname.startsWith('/login')
    ? '/login'
    : authenticated && pathname === '/login'
      ? '/dashboard'
      : null;

  if (!destination) return response;
  const redirect = NextResponse.redirect(new URL(destination, req.url));
  // Pertahankan cookie sesi yang diperbarui selama validasi JWT.
  response.cookies.getAll().forEach((cookie) => redirect.cookies.set(cookie));
  return redirect;
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp|ico)$).*)'],
};
