import type { ReactNode } from 'react';
import '@/styles/globals.css';

export const metadata = {
  title: "Kedai Nita's | Warehouse",
  description: 'Sistem manajemen stok gudang',
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="id">
      <body>{children}</body>
    </html>
  );
}
