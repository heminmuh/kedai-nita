import TransactionForm from '@/components/forms/transaction-form';
import PageHeader from '@/components/ui/page-header';
import FormModal from '@/components/ui/form-modal';
import OpnameTable from '@/components/forms/opname-table';
import { getActor, isOwner } from '@/lib/auth';
import { fetchProductOptions } from '@/lib/data/queries';
import { fetchOpnameDisplay } from '@/lib/data/display';

export default async function OpnamePage() {
  const { profile } = await getActor();
  const admin = isOwner(profile);
  const [allRows, products] = await Promise.all([fetchOpnameDisplay(), admin ? Promise.resolve([]) : fetchProductOptions()]);
  const rows = admin ? allRows : allRows.filter(row => Number(row.id_pengguna) === profile.id_pengguna);

  return <>
    <PageHeader eyebrow="WAREHOUSE / OPNAME" title="Stock Opname" description={admin ? 'Tinjau pengajuan stock opname dari petugas.' : 'Ajukan hasil pemeriksaan stok dan pantau keputusan admin.'} />
    {!admin && <FormModal title="Ajukan Opname" description="Isi hasil penghitungan stok fisik untuk diperiksa admin.">
      <TransactionForm kind="opname" products={products} suppliers={[]} petugasName={profile.nama_lengkap} />
    </FormModal>}
    <OpnameTable rows={rows} admin={admin}/>
  </>;
}
