/** Skeleton route transition. Sidebar stays mounted in the shared app layout. */
export default function Loading() {
  return (
    <div className="route-skeleton" role="status" aria-label="Memuat halaman" aria-live="polite">
      <div className="skeleton skeleton-kicker" />
      <div className="skeleton skeleton-title" />
      <div className="skeleton-grid">
        {Array.from({ length: 4 }, (_, i) => (
          <div className="skeleton-card" key={i}>
            <div className="skeleton skeleton-card-label" />
            <div className="skeleton skeleton-card-value" />
          </div>
        ))}
      </div>
      <div className="skeleton-panel">
        <div className="skeleton skeleton-panel-heading" />
        {Array.from({ length: 5 }, (_, i) => <div className="skeleton skeleton-table-row" key={i} />)}
      </div>
      <span className="sr-only">Sedang memuat konten...</span>
    </div>
  );
}
