import MasterPage from '@/components/master/master-page';

export default function Page() {
  return <MasterPage slug="supplier" />;
}
