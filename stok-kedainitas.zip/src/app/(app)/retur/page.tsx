import PageHeader from '@/components/ui/page-header';
import ReturnManager from '@/components/retur/return-manager';
import {fetchRows,fetchProductOptions,fetchSupplierOptions} from '@/lib/data/queries';
import {createClient} from '@/lib/supabase/server';
import {getActor} from '@/lib/auth';

export default async function ReturPage(){
 await getActor();
 const [headers,products,suppliers,people] = await Promise.all([fetchRows('retur_supplier','*',500),fetchProductOptions(),fetchSupplierOptions(),fetchRows('pengguna')]);
 const supabase=await createClient();
 const ids=headers.map(h=>Number(h.id_retur));
 const {data:details,error}=ids.length?await supabase.from('retur_supplier_detail').select('id_retur,id_barang,jumlah').in('id_retur',ids):{data:[],error:null};
 if(error) throw new Error(error.message);
 const pNames=new Map(products.map(p=>[p.id_barang,p.nama_barang]));
 const sNames=new Map(suppliers.map(s=>[s.id_supplier,s.nama_supplier]));
 const uNames=new Map(people.map(u=>[String(u.id_pengguna),String(u.nama_lengkap)]));
 const paths=headers.map(h=>String(h.foto_bukti??'')).filter(Boolean);
 const signed=new Map<string,string>();
 await Promise.all(paths.map(async path=>{const {data}=await supabase.storage.from('nota').createSignedUrl(path,60*15);if(data?.signedUrl)signed.set(path,data.signedUrl)}));
 const rows=headers.map(h=>({
   no_transaksi:String(h.no_transaksi),tanggal:String(h.tanggal),nama_supplier:sNames.get(Number(h.id_supplier))??'—',
   nama_petugas:uNames.get(String(h.id_pengguna))??'—',alasan:String(h.alasan??''),
   daftar_barang:(details??[]).filter(d=>String(d.id_retur)===String(h.id_retur)).map(d=>`${pNames.get(Number(d.id_barang))??'Barang'} × ${d.jumlah}`).join(' • '),
   foto_url:signed.get(String(h.foto_bukti??''))??''
 })).sort((a,b)=>b.tanggal.localeCompare(a.tanggal));
 return <><PageHeader eyebrow="WAREHOUSE / RETUR" title="Retur Barang" description="Catat pengembalian barang ke supplier dan pantau bukti retur."/>
  <ReturnManager rows={rows} products={products} suppliers={suppliers}/></>;
}
