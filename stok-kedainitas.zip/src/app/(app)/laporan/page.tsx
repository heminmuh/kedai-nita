import PageHeader from '@/components/ui/page-header';
import ReportPriceTable, { type ReportPriceRow } from '@/components/reports/report-price-table';
import { createClient } from '@/lib/supabase/server';
import { requireOwnerPage } from '@/lib/auth';

/** Perbandingan hanya dari dua catatan pembelian terakhir, bukan penyesuaian opname. */
export default async function LaporanPage() {
  await requireOwnerPage();
  const supabase = await createClient();
  const [{ data: products, error: productError }, { data: purchases, error: purchaseError }] = await Promise.all([
    supabase.from('barang').select('id_barang,kode_barang,nama_barang,satuan,stok_saat_ini,harga_beli_terakhir').order('nama_barang'),
    supabase.from('inbound_detail').select('id_barang,id_inbound_detail,harga_beli,inbound!inner(tanggal,jenis,dibuat_pada)').eq('inbound.jenis', 'pembelian').order('id_inbound_detail', { ascending: false }).limit(10000),
  ]);
  if (productError) throw new Error(`Gagal memuat barang: ${productError.message}`);
  if (purchaseError) throw new Error(`Gagal memuat riwayat pembelian: ${purchaseError.message}`);

  const history = new Map<number, { price: number; date: string; order: number }[]>();
  for (const purchase of purchases ?? []) {
    const inboundRaw = purchase.inbound as unknown;
    const inbound = (Array.isArray(inboundRaw) ? inboundRaw[0] : inboundRaw) as { tanggal?: string; jenis?: string; dibuat_pada?: string } | undefined;
    if (!inbound || inbound.jenis !== 'pembelian') continue;
    const id = Number(purchase.id_barang);
    const arr = history.get(id) ?? [];
    arr.push({ price: Number(purchase.harga_beli), date: inbound.tanggal ?? '', order: Number(purchase.id_inbound_detail) });
    history.set(id, arr);
  }

  const rows: ReportPriceRow[] = (products ?? []).map((product) => {
    const prices = (history.get(Number(product.id_barang)) ?? []).sort((a,b) => b.date.localeCompare(a.date) || b.order-a.order);
    const last = prices[0]?.price ?? null;
    const previous = prices[1]?.price ?? null;
    const diff = last != null && previous != null ? last - previous : null;
    return {
      id: Number(product.id_barang),
      code: String(product.kode_barang), name: String(product.nama_barang),
      stock: Number(product.stok_saat_ini), unit: String(product.satuan),
      lastPrice: last ?? Number(product.harga_beli_terakhir),
      previousPrice: previous,
      difference: diff,
      status: diff == null ? 'unknown' : diff > 0 ? 'up' : diff < 0 ? 'down' : 'stable',
    };
  });

  return <>
    <PageHeader eyebrow="WAREHOUSE / LAPORAN" title="Laporan" description="Pantau posisi stok dan perubahan harga beli berdasarkan riwayat transaksi pembelian." />
    <ReportPriceTable rows={rows} />
  </>;
}
