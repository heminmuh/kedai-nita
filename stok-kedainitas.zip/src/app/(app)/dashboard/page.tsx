import ActivityChart from '@/components/charts/activity-chart';
import ExportMenu from '@/components/dashboard/export-menu';
import DataTable from '@/components/ui/data-table';
import PageHeader from '@/components/ui/page-header';
import Panel from '@/components/ui/panel';
import StatCard from '@/components/ui/stat-card';
import { getActor, isOwner } from '@/lib/auth';
import { fetchRows } from '@/lib/data/queries';
import { lastDays } from '@/lib/utils/date';

export default async function DashboardPage() {
  const { profile } = await getActor();
  const [items, inbound, outbound] = await Promise.all([
    fetchRows('barang'),
    fetchRows('inbound'),
    fetchRows('outbound'),
  ]);

  const low = items.filter((x) => Number(x.stok_saat_ini) <= Number(x.stok_minimum));
  const activity = lastDays(7).map((date) => ({
    date,
    inbound: inbound.filter((x) => String(x.tanggal) === date).length,
    outbound: outbound.filter((x) => String(x.tanggal) === date).length,
  }));

  return (
    <>
      <PageHeader
        eyebrow="OVERVIEW / KEDAI NITA'S"
        title={`Selamat datang, ${profile.nama_lengkap.split(' ')[0]}`}
      />
      {isOwner(profile) && <div className="dashboard-export-toolbar"><p>Unduh laporan aktivitas gudang dalam format CSV.</p><ExportMenu /></div>}
      <div className="stats">
        <StatCard label="Total Produk" value={items.length} hint="Jenis barang terdaftar" />
        <StatCard label="Stok Menipis" value={low.length} hint="Perlu segera ditinjau" />
        <StatCard label="Transaksi Masuk" value={inbound.length} hint="Catatan penerimaan" />
        <StatCard label="Transaksi Keluar" value={outbound.length} hint="Catatan pemakaian" />
      </div>
      <Panel title="Aktivitas transaksi 7 hari terakhir">
        <ActivityChart values={activity} />
      </Panel>
      <Panel title="Perlu perhatian">
        <DataTable
          rows={low}
          columns={['kode_barang', 'nama_barang', 'stok_saat_ini', 'stok_minimum']}
        />
      </Panel>
    </>
  );
}
