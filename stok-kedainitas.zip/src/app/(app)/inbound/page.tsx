import TransactionForm from '@/components/forms/transaction-form';
import PageHeader from '@/components/ui/page-header';
import FormModal from '@/components/ui/form-modal';
import TransactionHistory from '@/components/ui/transaction-history';
import { fetchProductOptions, fetchSupplierOptions } from '@/lib/data/queries';
import { fetchTransactionDisplay } from '@/lib/data/display';

export default async function InboundPage() {
  const [rows, products, suppliers] = await Promise.all([
    fetchTransactionDisplay('inbound'),
    fetchProductOptions(),
    fetchSupplierOptions(),
  ]);

  return (
    <>
      <PageHeader eyebrow="WAREHOUSE / INBOUND" title="Barang Masuk" />
      <FormModal title="Catat Penerimaan" description="Isi detail transaksi dengan lengkap, lalu simpan.">
        <TransactionForm kind="inbound" products={products} suppliers={suppliers} />
      </FormModal>
      <TransactionHistory kind="inbound" rows={rows} />
    </>
  );
}
