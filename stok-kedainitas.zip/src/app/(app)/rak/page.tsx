import PageHeader from '@/components/ui/page-header';
import MasterManager from '@/components/master/master-manager';
import { requireOwnerPage } from '@/lib/auth';
import { fetchRackDisplay } from '@/lib/data/display';

export default async function Page() {
  await requireOwnerPage();
  const racks = await fetchRackDisplay();
  return <><PageHeader eyebrow="WAREHOUSE / RAK" title="Lokasi Rak" description="Atur nama dan lokasi rak; isi rak otomatis mengikuti penempatan pada Monitoring Barang." />
    <MasterManager slug="rak" rows={racks} editable={true} />
  </>;
}
