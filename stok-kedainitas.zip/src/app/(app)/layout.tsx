import type { ReactNode } from 'react';
import AdminShell from '@/components/layout/admin-shell';
import { getActor } from '@/lib/auth';

export default async function AppLayout({ children }: { children: ReactNode }) {
  const { profile } = await getActor();
  return <AdminShell profile={profile}>{children}</AdminShell>;
}
