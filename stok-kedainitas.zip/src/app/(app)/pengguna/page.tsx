import PageHeader from '@/components/ui/page-header';
import UserManager from '@/components/forms/user-manager';
import { requireOwnerPage } from '@/lib/auth';
import { fetchRows } from '@/lib/data/queries';
export default async function PenggunaPage(){await requireOwnerPage();const rows=await fetchRows('pengguna');return <><PageHeader eyebrow="WAREHOUSE / PENGGUNA" title="Pengguna"/><UserManager rows={rows}/></>;}
