import PageHeader from '@/components/ui/page-header';
import StockCardManager from '@/components/stock-card-manager';
import { fetchStockCardDisplay } from '@/lib/data/display';

export default async function KartuStokPage() {
  const rows = await fetchStockCardDisplay();
  return <>
    <PageHeader eyebrow="WAREHOUSE / KARTU STOK" title="Kartu Stok" description="Riwayat barang masuk, keluar, dan koreksi dari Stock Opname yang telah disetujui." />
    <StockCardManager rows={rows}/>
  </>;
}
