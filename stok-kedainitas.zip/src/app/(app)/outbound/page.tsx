import TransactionForm from '@/components/forms/transaction-form';
import PageHeader from '@/components/ui/page-header';
import FormModal from '@/components/ui/form-modal';
import TransactionHistory from '@/components/ui/transaction-history';
import { fetchProductOptions } from '@/lib/data/queries';
import { fetchTransactionDisplay } from '@/lib/data/display';

export default async function OutboundPage() {
  const [rows, products] = await Promise.all([fetchTransactionDisplay('outbound'), fetchProductOptions()]);

  return (
    <>
      <PageHeader eyebrow="WAREHOUSE / OUTBOUND" title="Barang Keluar" />
      <FormModal title="Catat Pengeluaran" description="Isi detail transaksi dengan lengkap, lalu simpan.">
        <TransactionForm kind="outbound" products={products} suppliers={[]} />
      </FormModal>
      <TransactionHistory kind="outbound" rows={rows} />
    </>
  );
}
