import PageHeader from '@/components/ui/page-header';
import Panel from '@/components/ui/panel';
import StockSearchTable from '@/components/ui/stock-search-table';
import { fetchStockDisplay } from '@/lib/data/display';

export default async function StokPage() {
  const rows = await fetchStockDisplay();
  return (
    <>
      <PageHeader eyebrow="WAREHOUSE / STOK" title="Monitoring Stok" />
      <Panel title="Daftar Monitoring Stok" badge={<span className="pill">{rows.length} data</span>}>
        <StockSearchTable rows={rows} />
      </Panel>
    </>
  );
}
