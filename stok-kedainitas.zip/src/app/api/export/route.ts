﻿import { NextRequest } from 'next/server';
import { requireOwner } from '@/lib/auth';
import { toCsv } from '@/lib/utils/csv';

type Row = Record<string, unknown>;
type ExportKind = 'stok' | 'masuk' | 'keluar' | 'retur' | 'opname' | 'ringkasan';
const kinds: ExportKind[] = ['stok','masuk','keluar','retur','opname','ringkasan'];

function safeRows(rows: Row[]) {
  // Mencegah CSV formula injection saat dibuka di Excel.
  return rows.map(row => Object.fromEntries(Object.entries(row).map(([key, value]) => {
    if (typeof value === 'string' && /^[\s\t\r\n]*[=+@-]/.test(value)) return [key, `'${value}`];
    return [key, value];
  })));
}

export async function GET(request: NextRequest) {
  try {
    const { supabase } = await requireOwner('Hanya admin dapat mengekspor laporan.');
    const requested = request.nextUrl.searchParams.get('type') || 'stok';
    if (!kinds.includes(requested as ExportKind)) return new Response('Jenis ekspor tidak valid', { status: 400 });
    const kind = requested as ExportKind;
    async function query(table: string, columns: string, orderBy?: string) {
      let builder = supabase.from(table).select(columns);
      if (orderBy) builder = builder.order(orderBy, { ascending: false });
      const { data, error } = await builder.limit(5000);
      if (error) throw error;
      return (data ?? []) as unknown as Row[];
    }
    const products = await query('barang', 'id_barang,kode_barang,nama_barang,kategori,satuan,stok_saat_ini,stok_minimum,harga_beli_terakhir');
    const productsById = new Map(products.map(p => [String(p.id_barang), p]));
    const name = (id: unknown) => String(productsById.get(String(id))?.nama_barang ?? 'â€”');
    let columns: string[] = [];
    let rows: Row[] = [];
    if (kind === 'stok') {
      columns = ['kode_barang','nama_barang','kategori','satuan','stok_saat_ini','stok_minimum','harga_beli_terakhir','status_stok'];
      rows = products.map(p => ({...p, status_stok: Number(p.stok_saat_ini) <= Number(p.stok_minimum) ? 'Menipis' : 'Aman'}));
    } else if (kind === 'ringkasan') {
      const [inbound, outbound, returns, opname] = await Promise.all([
        query('inbound','id_inbound'), query('outbound','id_outbound'), query('retur_supplier','id_retur'), query('stock_opname','id_opname,status'),
      ]);
      columns = ['indikator','jumlah'];
      rows = [
        { indikator: 'Total Produk', jumlah: products.length },
        { indikator: 'Stok Menipis', jumlah: products.filter(p => Number(p.stok_saat_ini) <= Number(p.stok_minimum)).length },
        { indikator: 'Transaksi Masuk', jumlah: inbound.length },
        { indikator: 'Transaksi Keluar', jumlah: outbound.length },
        { indikator: 'Retur Supplier', jumlah: returns.length },
        { indikator: 'Stock Opname Menunggu', jumlah: opname.filter(o => o.status === 'menunggu').length },
      ];
    } else if (kind === 'masuk' || kind === 'keluar' || kind === 'retur') {
      const table = kind === 'masuk' ? 'inbound' : kind === 'keluar' ? 'outbound' : 'retur_supplier';
      const idField = kind === 'masuk' ? 'id_inbound' : kind === 'keluar' ? 'id_outbound' : 'id_retur';
      const detailTable = kind === 'masuk' ? 'inbound_detail' : kind === 'keluar' ? 'outbound_detail' : 'retur_supplier_detail';
      const headers = await query(table, '*','tanggal');
      const detail = await query(detailTable, `${idField},id_barang,jumlah${kind === 'masuk' ? ',harga_beli' : ''}`);
      const people = await query('pengguna','id_pengguna,nama_lengkap');
      const personMap = new Map(people.map(p => [String(p.id_pengguna), String(p.nama_lengkap)]));
      const supplierMap = new Map((await query('supplier','id_supplier,nama_supplier')).map(s => [String(s.id_supplier), String(s.nama_supplier)]));
      columns = ['tanggal','no_transaksi','nama_barang','jumlah','satuan','nama_petugas', ...(kind === 'masuk' ? ['supplier','harga_beli'] : kind === 'keluar' ? ['tujuan'] : ['supplier','alasan']), 'catatan'];
      const map = new Map(headers.map(h => [String(h[idField]),h]));
      rows = detail.flatMap(d => {
        const h = map.get(String(d[idField])); if (!h) return [];
        return [{
          tanggal: h.tanggal, no_transaksi: h.no_transaksi, nama_barang: name(d.id_barang), jumlah: d.jumlah,
          satuan: productsById.get(String(d.id_barang))?.satuan ?? '', nama_petugas: personMap.get(String(h.id_pengguna)) ?? 'â€”',
          supplier: supplierMap.get(String(h.id_supplier)) ?? 'â€”', harga_beli: d.harga_beli ?? '',
          tujuan: h.tujuan ?? '', alasan: h.alasan ?? '', catatan: h.catatan ?? '',
        }];
      });
    } else if (kind === 'opname') {
      const [headers, detail, people] = await Promise.all([
        query('stock_opname','*','tanggal'), query('stock_opname_detail','id_opname,id_barang,stok_sistem,stok_fisik,selisih,alasan'), query('pengguna','id_pengguna,nama_lengkap')
      ]);
      const map = new Map(headers.map(h => [String(h.id_opname), h]));
      const peopleMap = new Map(people.map(p => [String(p.id_pengguna), String(p.nama_lengkap)]));
      columns = ['tanggal','no_transaksi','nama_barang','stok_sistem','stok_fisik','selisih','alasan_selisih','nama_petugas','status','alasan_keputusan'];
      rows = detail.flatMap(d => {
        const h = map.get(String(d.id_opname)); if (!h) return [];
        return [{ tanggal:h.tanggal, no_transaksi:h.no_transaksi, nama_barang:name(d.id_barang), stok_sistem:d.stok_sistem,
          stok_fisik:d.stok_fisik, selisih:d.selisih, alasan_selisih:d.alasan ?? '',
          nama_petugas: peopleMap.get(String(h.id_pengguna)) ?? 'â€”', status:h.status,
          alasan_keputusan:h.catatan_penyetuju ?? '' }];
      });
    }
    const csv = toCsv(columns, safeRows(rows));
    const filename = `kedai-nitas-${kind}-${new Date().toISOString().slice(0,10)}.csv`;
    return new Response(csv, { headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="${filename}"`,
      'Cache-Control': 'private, no-store',
    }});
  } catch (error) {
    return new Response(error instanceof Error && /Sesi|login|aktif/.test(error.message) ? 'Login diperlukan' : 'Gagal membuat CSV', { status: 500 });
  }
}

