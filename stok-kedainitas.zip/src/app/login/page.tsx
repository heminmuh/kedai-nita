import LoginForm from '@/components/auth/login-form';

export default function LoginPage() {
  return (
    <main className="login login-modern-shell">
      <LoginForm />
    </main>
  );
}
