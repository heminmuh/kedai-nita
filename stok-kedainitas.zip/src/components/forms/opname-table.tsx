'use client';

import { useMemo, useState } from 'react';
import { CheckCircle2, ClipboardCheck, Search, XCircle } from 'lucide-react';
import type { Row } from '@/lib/types';
import { useRouter } from 'next/navigation';
import Modal from '@/components/ui/modal';
import { reviewOpname } from '@/lib/actions/inventory';
import { confirmAlert, errorAlert, successAlert } from '@/lib/alerts';

function getStatus(s: unknown) {
  switch (String(s).toLowerCase()) {
    case 'disetujui': return { label: 'Disetujui', klass: 'approved' };
    case 'ditolak': return { label: 'Ditolak', klass: 'rejected' };
    default: return { label: 'Menunggu', klass: 'pending' };
  }
}
function dateOnly(value: unknown) {
  const s = String(value ?? '');
  return s.slice(0, 10);
}
export default function OpnameTable({ rows, admin }: { rows: Row[]; admin: boolean }) {
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('all');
  const [selected, setSelected] = useState<Row | null>(null);
  const [decision, setDecision] = useState('approve');
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  const filtered = useMemo(() => rows.filter(row => {
    const date = dateOnly(row.tanggal);
    if (from && date < from || to && date > to) return false;
    if (status !== 'all' && String(row.status) !== status) return false;
    return [row.no_transaksi, row.diajukan_oleh, row.barang_diperiksa, row.catatan, row.catatan_penyetuju]
      .some(v => String(v ?? '').toLowerCase().includes(search.toLowerCase()));
  }), [rows, from, to, search, status]);
  async function submit(form: FormData) {
    if (!selected || busy) return;
    if (!reason.trim()) { await errorAlert(new Error('Alasan keputusan wajib diisi.')); return; }
    if (!await confirmAlert(decision === 'approve' ? 'Setujui opname?' : 'Tolak opname?', decision === 'approve' ? 'Stok otomatis disesuaikan dengan hasil perhitungan, dicatat di Kartu Stok, dan alasan terlihat oleh petugas.' : 'Stok tidak berubah. Alasan penolakan akan terlihat oleh petugas.')) return;
    setBusy(true);
    try {
      await reviewOpname(form);
      setSelected(null);
      setReason('');
      await successAlert(decision === 'approve' ? 'Opname disetujui, stok diperbarui' : 'Opname ditolak, stok tetap');
      router.refresh();
    } catch (e) { await errorAlert(e); } finally { setBusy(false); }
  }
  return <section className="panel modern-panel">
    <div className="data-toolbar"><div><span className="section-kicker">{admin ? 'PERSETUJUAN ADMIN' : 'RIWAYAT PENGAJUAN'}</span><h2>Daftar Stock Opname</h2><p>{admin ? 'Tinjau pengajuan petugas dan sertakan alasan keputusan.' : 'Lihat status dan alasan keputusan dari admin.'}</p></div><span className="count-badge">{filtered.length} data</span></div>
    <div className="opname-filters">
      <label className="search-field"><Search size={17}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Cari transaksi atau barang..." aria-label="Cari stock opname"/></label>
      <label>Dari tanggal<input type="date" value={from} max={to || undefined} onChange={e=>setFrom(e.target.value)}/></label>
      <label>Sampai tanggal<input type="date" value={to} min={from || undefined} onChange={e=>setTo(e.target.value)}/></label>
      <label>Status<select value={status} onChange={e=>setStatus(e.target.value)}><option value="all">Semua status</option><option value="menunggu">Menunggu</option><option value="disetujui">Disetujui</option><option value="ditolak">Ditolak</option></select></label>
      <button type="button" className="button-outline" onClick={()=>{setFrom('');setTo('');setSearch('');setStatus('all');}}>Reset</button>
    </div>
    <div className="table-scroll"><table><thead><tr><th>No Transaksi</th><th>Tanggal</th><th>Diajukan Oleh</th><th>Hasil Perhitungan</th><th>Status</th><th>Catatan Petugas</th><th>Foto Bukti</th><th>Alasan Keputusan</th>{admin && <th>Aksi</th>}</tr></thead>
      <tbody>{filtered.map(row => {const state=getStatus(row.status);return <tr key={String(row.id_opname)}><td>{String(row.no_transaksi ?? 'â€”')}</td><td>{dateOnly(row.tanggal)}</td><td>{String(row.diajukan_oleh ?? 'â€”')}</td><td>{String(row.barang_diperiksa ?? 'â€”')}</td><td><span className={`opname-status opname-${state.klass}`}>{state.label}</span></td><td>{String(row.catatan || 'â€”')}</td><td>{row.foto_url ? <a href={String(row.foto_url)} target="_blank" rel="noopener noreferrer" aria-label={`Lihat foto bukti ${String(row.no_transaksi)}`}><img src={String(row.foto_url)} alt="Bukti stock opname" className="opname-photo-thumb" /></a> : 'â€”'}</td><td>{String(row.catatan_penyetuju || (state.klass === 'pending' ? 'Belum ditinjau' : 'â€”'))}</td>{admin && <td>{state.klass === 'pending' ? <button type="button" className="table-edit" onClick={()=>{setSelected(row);setDecision('approve');setReason('');}}><ClipboardCheck size={15}/> Tinjau</button> : 'â€”'}</td>}</tr>;})}</tbody></table>{!filtered.length && <p className="muted" style={{padding:18}}>Tidak ada pengajuan pada filter ini.</p>}</div>
    <Modal open={!!selected} onClose={()=>!busy&&setSelected(null)} title="Tinjau Stock Opname" description={String(selected?.no_transaksi ?? '')}>
      {selected && <form action={submit} className="modal-form"><div className="modal-scroll-region"><input type="hidden" name="id" value={String(selected.id_opname)}/><div className="modal-fields"><div className="wide"><strong>Diajukan oleh:</strong> {String(selected.diajukan_oleh ?? 'â€”')}<p><strong>Hasil pemeriksaan:</strong> {String(selected.barang_diperiksa ?? 'â€”')}</p>{Boolean(selected.foto_url) && <a href={String(selected.foto_url)} target="_blank" rel="noopener noreferrer" className="opname-photo-review"><img src={String(selected.foto_url)} alt="Foto bukti pemeriksaan stok" />Lihat foto ukuran penuh</a>}</div><label>Keputusan<select name="decision" value={decision} onChange={e=>setDecision(e.target.value)}><option value="approve">Setujui</option><option value="reject">Tolak</option></select></label><label className="wide">Alasan keputusan <span className="required-star" aria-hidden="true">*</span><textarea name="note" required minLength={3} maxLength={1000} rows={3} value={reason} onChange={e=>setReason(e.target.value)} placeholder="Tuliskan alasan persetujuan atau penolakan..."/></label></div></div><div className="modal-footer"><button type="button" className="button-outline" disabled={busy} onClick={()=>setSelected(null)}>Batal</button><button disabled={busy || reason.trim().length < 3}>{busy ? 'Memproses...' : decision === 'approve' ? 'Setujui Opname' : 'Tolak Opname'}</button></div></form>}
    </Modal>
  </section>;
}

