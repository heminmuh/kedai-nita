'use client';

import { useState } from 'react';
import { ImagePlus, Trash2, Plus, FileImage } from 'lucide-react';
import { confirmAlert, errorAlert, successAlert } from '@/lib/alerts';
import { submitInbound, submitOpname, submitOutbound } from '@/lib/actions/inventory';
import { uploadNota } from '@/lib/actions/storage';
import type { ProductOption, SupplierOption, TransactionKind } from '@/lib/types';

interface Item {
  id_barang: number;
  jumlah: number;
  harga_beli: number;
  tgl_kedaluwarsa: string;
  stok_fisik: number;
  alasan: string;
}

const NUMERIC_KEYS: (keyof Item)[] = ['id_barang', 'jumlah', 'harga_beli', 'stok_fisik'];

const emptyItem = (): Item => ({
  id_barang: 0,
  jumlah: 1,
  harga_beli: 0,
  tgl_kedaluwarsa: '',
  stok_fisik: 0,
  alasan: '',
});

const SUBMIT_ACTIONS = {
  inbound: submitInbound,
  outbound: submitOutbound,
  opname: submitOpname,
} as const;

/** Bentuk payload `items` sesuai jenis transaksi (dikirim ke RPC Postgres). */
function buildPayload(kind: TransactionKind, items: Item[]) {
  return items.map((x) => {
    if (kind === 'inbound') {
      return {
        id_barang: x.id_barang,
        jumlah: x.jumlah,
        harga_beli: x.harga_beli,
        tgl_kedaluwarsa: x.tgl_kedaluwarsa || null,
      };
    }
    if (kind === 'outbound') return { id_barang: x.id_barang, jumlah: x.jumlah };
    return { id_barang: x.id_barang, stok_fisik: x.stok_fisik, alasan: x.alasan };
  });
}

function validate(items: Item[]) {
  if (items.some((x) => !x.id_barang)) throw new Error('Pilih barang pada semua baris');
  if (new Set(items.map((x) => x.id_barang)).size !== items.length) {
    throw new Error('Barang duplikat: gabungkan dalam satu baris');
  }
}

interface Props {
  kind: TransactionKind;
  products: ProductOption[];
  suppliers: SupplierOption[];
  petugasName?: string;
}

export default function TransactionForm({ kind, products, suppliers, petugasName }: Props) {
  const [items, setItems] = useState<Item[]>([emptyItem()]);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [file, setFile] = useState<File | null>(null);

  function edit(index: number, key: keyof Item, value: string) {
    setItems((rows) =>
      rows.map((row, i) =>
        i === index ? { ...row, [key]: NUMERIC_KEYS.includes(key) ? Number(value) : value } : row,
      ),
    );
  }

  async function send(form: FormData) {
    setBusy(true);
    setError('');
    try {
      validate(items);
      if (kind === 'opname' && items.some(x => !x.alasan.trim())) throw new Error('Alasan selisih wajib diisi.');
      if (!await confirmAlert('Simpan transaksi?', 'Pastikan barang dan jumlah sudah sesuai.')) return;

      if (!file) throw new Error('Foto bukti wajib diunggah untuk setiap transaksi.');
      if (file) {
        const fd = new FormData();
        fd.set('file', file);
        form.set('foto_nota', await uploadNota(fd));
      }

      form.set('items', JSON.stringify(buildPayload(kind, items)));
      await SUBMIT_ACTIONS[kind](form);
      await successAlert('Transaksi berhasil disimpan');
      window.location.reload();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Gagal menyimpan');
      await errorAlert(e);
    } finally {
      setBusy(false);
    }
  }

  return (
    <form action={send} className="transaction-form transaction-form-modern">
      <div className="modal-scroll-region">
      <div className="transaction-general">
        <div className="transaction-section-heading"><span className="transaction-step">01</span><div><strong>Informasi transaksi</strong><small>Lengkapi data utama dan foto bukti transaksi.</small></div></div>
        <div className="transaction-main-fields">
          {kind === 'inbound' && (
            <label><span className="field-label">Supplier</span><select name="id_supplier"><option value="">Tanpa supplier</option>{suppliers.map(s=><option key={s.id_supplier} value={s.id_supplier}>{s.nama_supplier}</option>)}</select></label>
          )}
          {kind === 'outbound' && (
            <label><span className="field-label">Tujuan pengeluaran <span className="required-star" aria-hidden="true">*</span></span><input name="tujuan" required placeholder="Contoh: Operasional kedai" /></label>
          )}
          {kind === 'opname' && <label><span className="field-label">Nama petugas pengaju</span><input value={petugasName || 'Petugas aktif'} readOnly aria-label="Nama petugas pengaju" /></label>}
          <label><span className="field-label">Catatan <span className="optional-note">(opsional)</span></span><input name="catatan" placeholder="Tambahkan catatan bila diperlukan" /></label>
          <div className="evidence-field">
            <div className="field-label">{kind === 'inbound' ? 'Foto catatan penerimaan / nota' : kind === 'outbound' ? 'Foto bukti pengeluaran' : 'Foto bukti pemeriksaan stok'} <span className="required-star" aria-hidden="true">*</span></div>
            <label className="evidence-dropzone">
              <input type="file" required accept="image/jpeg,image/png,image/webp" className="evidence-file-input" onChange={e=>setFile(e.target.files?.[0] || null)} />
              <span className="evidence-upload-icon">{file ? <FileImage size={22} /> : <ImagePlus size={22} />}</span>
              <span className="evidence-upload-text"><strong>{file ? file.name : 'Pilih foto bukti transaksi'}</strong><small>{file ? `${(file.size / 1024 / 1024).toFixed(2)} MB · Klik untuk mengganti foto` : 'JPG, PNG, atau WebP · Maksimal 2 MB · 1 gambar'}</small></span>
              <span className="evidence-upload-action">Pilih foto</span>
            </label>
          </div>
        </div>
      </div>

      <div className="transaction-items-section">
        <div className="transaction-section-heading"><span className="transaction-step">02</span><div><strong>Detail barang</strong><small>{kind === 'opname' ? 'Masukkan hasil perhitungan stok fisik.' : 'Masukkan barang dan jumlah transaksi.'}</small></div></div>
        <div className="transaction-items-list">
          {items.map((row, i) => (
            <div className="transaction-item-card" key={i}>
              <div className="transaction-item-header"><span>Barang {String(i+1).padStart(2,'0')}</span><button type="button" className="transaction-item-remove" onClick={() => setItems(rows => rows.filter((_, j) => j !== i))} disabled={items.length === 1} aria-label={`Hapus barang ${i+1}`}><Trash2 size={15}/> Hapus</button></div>
              <div className="transaction-item-grid">
                <label className="item-product"><span className="field-label">Barang <span className="required-star" aria-hidden="true">*</span></span><select value={row.id_barang} onChange={e=>edit(i,'id_barang',e.target.value)} required><option value="0">Pilih barang</option>{products.map(p=><option key={p.id_barang} value={p.id_barang}>{p.nama_barang} (stok {p.stok_saat_ini})</option>)}</select></label>
                {kind !== 'opname' && <label><span className="field-label">Jumlah <span className="required-star" aria-hidden="true">*</span></span><input type="number" min="0.01" step="0.01" value={row.jumlah} onChange={e=>edit(i,'jumlah',e.target.value)} required /></label>}
                {kind === 'inbound' && <><label><span className="field-label">Harga beli</span><input type="number" min="0" step="0.01" value={row.harga_beli} onChange={e=>edit(i,'harga_beli',e.target.value)} /></label><label><span className="field-label">Kedaluwarsa <span className="optional-note">(opsional)</span></span><input type="date" value={row.tgl_kedaluwarsa} onChange={e=>edit(i,'tgl_kedaluwarsa',e.target.value)} /></label></>}
                {kind === 'opname' && <><label><span className="field-label">Stok fisik <span className="required-star" aria-hidden="true">*</span></span><input type="number" min="0" step="0.01" value={row.stok_fisik} onChange={e=>edit(i,'stok_fisik',e.target.value)} required /></label><label className="item-reason"><span className="field-label">Alasan selisih <span className="required-star" aria-hidden="true">*</span></span><input required value={row.alasan} onChange={e=>edit(i,'alasan',e.target.value)} placeholder="Jelaskan hasil selisih stok" /></label></>}
              </div>
            </div>
          ))}
        </div>
        <button type="button" className="transaction-add-item" onClick={() => setItems(rows => [...rows, emptyItem()])}><Plus size={17}/> Tambah barang lainnya</button>
      </div>
      {error && <p role="alert" className="form-error">{error}</p>}
      </div>
      <div className="transaction-action-footer"><span className="transaction-required-info"><span className="required-star">*</span> Wajib diisi</span><button disabled={busy} className="transaction-submit">{busy ? 'Menyimpan...' : 'Simpan transaksi'}</button></div>
    </form>
  );
}
