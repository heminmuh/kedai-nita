'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Pencil, Search, Plus } from 'lucide-react';
import type { Row } from '@/lib/types';
import { createWarehouseUser, updateProfile } from '@/lib/actions/users';
import { confirmAlert, errorAlert, successAlert } from '@/lib/alerts';
import DataTable from '@/components/ui/data-table';
import Modal from '@/components/ui/modal';
import PasswordField from '@/components/ui/password-field';

export default function UserManager({ rows }: { rows: Row[] }) {
  const [current, setCurrent] = useState<Row | null>(null);
  const [adding, setAdding] = useState(false);
  const [query, setQuery] = useState('');
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  const visible = rows.filter(r => Object.values(r).some(v => String(v ?? '').toLowerCase().includes(query.toLowerCase())));
  const close = () => { if (!busy) { setAdding(false); setCurrent(null); } };

  async function submit(form: FormData) {
    const isCreate = adding;
    if (!await confirmAlert(isCreate ? 'Tambah pengguna?' : 'Perbarui akun?', isCreate ? 'Akun login baru akan dibuat.' : 'Peran dan status pengguna akan diperbarui.')) return;
    setBusy(true);
    try {
      if (isCreate) await createWarehouseUser(form);
      else await updateProfile(form);
      setAdding(false);
      setCurrent(null);
      await successAlert(isCreate ? 'Pengguna berhasil ditambahkan' : 'Akun berhasil diperbarui');
      router.refresh();
    } catch (error) { await errorAlert(error); }
    finally { setBusy(false); }
  }

  return <section className="panel modern-panel">
    <div className="data-toolbar">
      <div><span className="section-kicker">AKSES SISTEM</span><h2>Daftar Pengguna</h2><p>Kelola akun, hak akses, dan status pengguna warehouse.</p></div>
      <div className="toolbar-actions"><button type="button" className="primary-action" onClick={() => { setCurrent(null); setAdding(true); }}><Plus size={17} /> Tambah Pengguna</button></div>
    </div>
    <div className="table-tools"><label className="search-field"><Search size={17}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Cari pengguna..." /></label><span className="count-badge">{visible.length} akun</span></div>
    <DataTable rows={visible} columns={['nama_lengkap', 'username', 'peran', 'aktif']} action={r => <button className="table-edit" onClick={() => { setAdding(false); setCurrent(r); }}><Pencil size={15} /> Edit</button>} />
    <Modal open={adding || !!current} onClose={close} title={adding ? 'Tambah Pengguna' : 'Edit Pengguna'} description={adding ? 'Buat akun login dan tetapkan akses pengguna.' : 'Perbarui informasi dan hak akses akun.'}>
      {adding ? <form action={submit} className="modal-form"><div className="modal-scroll-region">
        <div className="modal-fields">
          <label>Nama lengkap <span className="required-star" aria-hidden="true">*</span><input name="nama_lengkap" autoComplete="name" minLength={2} maxLength={100} required placeholder="Nama pengguna" /></label>
          <label>Username <span className="required-star" aria-hidden="true">*</span><input name="username" minLength={3} maxLength={32} pattern="[a-zA-Z0-9._-]+" required placeholder="contoh: petugas01" /></label>
          <label>Email login <span className="required-star" aria-hidden="true">*</span><input name="email" type="email" autoComplete="off" required placeholder="nama@perusahaan.com" /></label>
          <PasswordField label="Password awal" name="password" autoComplete="new-password" minLength={8} required placeholder="Minimal 8 karakter" />
          <label>Peran <span className="required-star" aria-hidden="true">*</span><select name="peran" defaultValue="petugas"><option value="petugas">Petugas</option><option value="admin">Admin</option></select></label>
          <label>Status <span className="required-star" aria-hidden="true">*</span><select name="aktif" defaultValue="true"><option value="true">Aktif</option><option value="false">Nonaktif</option></select></label>
        </div>
        </div><div className="modal-footer"><button type="button" className="button-outline" onClick={close} disabled={busy}>Batal</button><button disabled={busy}>{busy ? 'Membuat akun...' : 'Tambah Pengguna'}</button></div>
      </form> : current && <form key={String(current.id_pengguna)} action={submit} className="modal-form"><div className="modal-scroll-region">
        <input type="hidden" name="id_pengguna" value={String(current.id_pengguna)} />
        <div className="modal-fields">
          <label>Username <span className="required-star" aria-hidden="true">*</span><input value={String(current.username)} readOnly /></label>
          <label>Nama lengkap <span className="required-star" aria-hidden="true">*</span><input name="nama_lengkap" defaultValue={String(current.nama_lengkap ?? '')} required /></label>
          <label>Peran <span className="required-star" aria-hidden="true">*</span><select name="peran" defaultValue={String(current.peran)}><option value="petugas">Petugas</option><option value="admin">Admin</option></select></label>
          <label>Status <span className="required-star" aria-hidden="true">*</span><select name="aktif" defaultValue={String(current.aktif)}><option value="true">Aktif</option><option value="false">Nonaktif</option></select></label>
        </div>
        </div><div className="modal-footer"><button type="button" className="button-outline" onClick={close} disabled={busy}>Batal</button><button disabled={busy}>{busy ? 'Menyimpan...' : 'Simpan perubahan'}</button></div>
      </form>}
    </Modal>
  </section>;
}
