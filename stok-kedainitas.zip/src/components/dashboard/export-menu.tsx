'use client';

import { useState } from 'react';
import { Download, ChevronDown, FileSpreadsheet } from 'lucide-react';

const options = [
  ['ringkasan', 'Ringkasan Dashboard'],
  ['stok', 'Monitoring Stok'],
  ['masuk', 'Barang Masuk'],
  ['keluar', 'Barang Keluar'],
  ['retur', 'Retur Barang'],
  ['opname', 'Stock Opname'],
] as const;

export default function ExportMenu() {
  const [open,setOpen] = useState(false);
  return <div className="dashboard-export-wrap">
    <button type="button" className="dashboard-export-button" onClick={() => setOpen(v=>!v)} aria-expanded={open} aria-controls="dashboard-export-list">
      <Download size={18}/> Download CSV <ChevronDown size={16}/>
    </button>
    {open && <div id="dashboard-export-list" className="dashboard-export-list">
      <strong>Pilih laporan</strong>
      {options.map(([value,label]) => <a key={value} href={`/api/export?type=${value}`} onClick={()=>setOpen(false)}>
        <FileSpreadsheet size={16}/>{label}
      </a>)}
    </div>}
  </div>;
}
