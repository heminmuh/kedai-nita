'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Plus, Pencil, Search, Trash2 } from 'lucide-react';
import type { Row } from '@/lib/types';
import { MASTER_CONFIG, type MasterSlug } from '@/lib/config/master';
import { saveMaster, deleteMaster } from '@/lib/actions/master';
import { confirmAlert, errorAlert, successAlert } from '@/lib/alerts';
import Modal from '@/components/ui/modal';
import DataTable from '@/components/ui/data-table';

export default function MasterManager({slug,rows,editable,racks=[],suppliers=[]}:{slug:MasterSlug;rows:Row[];editable:boolean;racks?:Row[];suppliers?:Row[]}) {
 const cfg=MASTER_CONFIG[slug];const [open,setOpen]=useState(false);const [current,setCurrent]=useState<Row|null>(null);
 const [query,setQuery]=useState('');const [busy,setBusy]=useState(false);const router=useRouter();
 const visible=rows.filter(row=>Object.values(row).some(value=>String(value??'').toLowerCase().includes(query.toLowerCase())));
 function show(row:Row|null){if(!editable)return;setCurrent(row);setOpen(true);}
 async function submit(form:FormData){
  if(!editable) { await errorAlert('Akses tambah/edit hanya untuk admin.'); return; }
  if(!await confirmAlert(current?'Simpan perubahan?':'Tambah data baru?',`Data ${cfg.title.toLowerCase()} akan disimpan.`))return;
  setBusy(true);try{await saveMaster(form);setOpen(false);await successAlert(current?'Perubahan disimpan':'Data ditambahkan');router.refresh();}catch(err){await errorAlert(err);}finally{setBusy(false);}
 }
 async function remove(row:Row){
  if(busy || !editable)return;
  const label=String(row[slug==='barang'?'nama_barang':slug==='rak'?'nama_rak':'nama_supplier']??'data ini');
  if(!await confirmAlert(`Hapus ${label}?`,'Data yang masih dipakai barang atau transaksi tidak bisa dihapus. Tindakan ini permanen.'))return;
  const form=new FormData();form.set('slug',slug);form.set('id',String(row[cfg.idKey]));
  setBusy(true);
  try{await deleteMaster(form);await successAlert('Data berhasil dihapus');router.refresh();}
  catch(err){await errorAlert(err);}finally{setBusy(false);}
 }
 return <section className="panel modern-panel">
  <div className="data-toolbar"><div><span className="section-kicker">DATA MASTER</span><h2>Daftar {cfg.title}</h2><p>Kelola dan temukan data dengan cepat.</p></div><div className="toolbar-actions"><button type="button" onClick={()=>show(null)} className="primary-action" disabled={!editable} title={!editable ? "Hanya admin dapat menambah data" : undefined}><Plus size={17}/> Tambah {cfg.title}</button></div></div>
  {!editable && <p className="master-role-notice">Akun ini berperan sebagai Petugas Gudang. Tambah, Edit, dan Hapus hanya dapat dilakukan oleh admin. Minta admin mengubah peran akun jika memang diperlukan.</p>}
  <div className="table-tools"><label className="search-field"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Cari data..." aria-label="Cari data" /></label><span className="count-badge">{visible.length} data</span></div>
  <DataTable rows={visible} columns={[...cfg.columns]} action={(row)=><div className="master-actions"><button type="button" className="table-edit" onClick={()=>show(row)} disabled={busy || !editable} title={!editable ? "Hanya admin" : undefined}><Pencil size={15}/> Edit</button><button type="button" className="table-delete" onClick={()=>remove(row)} disabled={busy || !editable} title={!editable ? "Hanya admin" : undefined} aria-label={`Hapus ${cfg.title}`}><Trash2 size={15}/> Hapus</button></div>}/>
  <Modal open={open} onClose={()=>!busy&&setOpen(false)} title={`${current?'Edit':'Tambah'} ${cfg.title}`} description="Lengkapi informasi pada kolom berikut.">
    <form key={current?String(current[cfg.idKey]):'new'} action={submit} className="modal-form"><div className="modal-scroll-region">
      <input type="hidden" name="slug" value={slug}/>{current&&<input type="hidden" name="id" value={String(current[cfg.idKey])}/>}
      <div className="modal-fields">{cfg.fields.map(field=><label key={field.name}><span className="field-label">{field.name === 'id_rak' ? 'Lokasi Rak' : field.name === 'id_supplier_utama' ? 'Supplier Utama' : field.name.replaceAll('_',' ')}{('required' in field && field.required) ? <span className="required-star" aria-hidden="true"> *</span> : null}</span>{field.kind === 'ref' ? <select name={field.name} defaultValue={current?.[field.name] == null ? '' : String(current[field.name])}>
        <option value="">Belum ditentukan</option>
        {(field.name === 'id_rak' ? racks : suppliers).map(option => <option key={String(option[field.name === 'id_rak' ? 'id_rak' : 'id_supplier'])} value={String(option[field.name === 'id_rak' ? 'id_rak' : 'id_supplier'])}>{String(option[field.name === 'id_rak' ? 'nama_rak' : 'nama_supplier'])}</option>)}
      </select> : <input name={field.name} type={field.kind === 'text' ? 'text' : 'number'} step={field.kind === 'text' ? undefined : 'any'} required={'required' in field && field.required} defaultValue={current?.[field.name] == null ? '' : String(current[field.name])} placeholder={`Masukkan ${field.name.replaceAll('_',' ')}`} />}</label>)}</div>
      </div><div className="modal-footer"><button type="button" className="button-outline" onClick={()=>setOpen(false)} disabled={busy}>Batal</button><button disabled={busy}>{busy?'Menyimpan...':'Simpan Data'}</button></div>
    </form>
  </Modal>
 </section>;
}

