import PageHeader from '@/components/ui/page-header';
import { requireOwnerPage } from '@/lib/auth';
import { MASTER_CONFIG, type MasterSlug } from '@/lib/config/master';
import { fetchRows } from '@/lib/data/queries';
import { fetchStockDisplay } from '@/lib/data/display';
import MasterManager from './master-manager';

export default async function MasterPage({ slug }: { slug: MasterSlug }) {
  const cfg = MASTER_CONFIG[slug];
  await requireOwnerPage();
  const [rows, racks, suppliers] = await Promise.all([slug === 'barang' ? fetchStockDisplay() : fetchRows(cfg.table), slug === 'barang' ? fetchRows('lokasi_rak') : Promise.resolve([]), slug === 'barang' ? fetchRows('supplier') : Promise.resolve([])]);
  return <><PageHeader eyebrow={`WAREHOUSE / ${slug.toUpperCase()}`} title={cfg.title} description="Kelola data gudang dalam satu tempat."/><MasterManager slug={slug} rows={rows} editable={true} racks={racks} suppliers={suppliers}/></>;
}
