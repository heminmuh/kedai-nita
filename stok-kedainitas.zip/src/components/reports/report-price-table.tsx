'use client';

import { useMemo, useState } from 'react';
import { ArrowDown, ArrowUp, Search, X } from 'lucide-react';

export type ReportPriceRow = {
  id: number; code: string; name: string; stock: number; unit: string;
  lastPrice: number; previousPrice: number | null; difference: number | null;
  status: 'up' | 'down' | 'stable' | 'unknown';
};

const money = (n:number) => new Intl.NumberFormat('id-ID', {style:'currency',currency:'IDR',maximumFractionDigits:0}).format(n);
const number = (n:number) => new Intl.NumberFormat('id-ID', {maximumFractionDigits:2}).format(n);

export default function ReportPriceTable({ rows }: { rows: ReportPriceRow[] }) {
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('all');
  const visible = useMemo(() => rows.filter(row => {
    const q = search.toLocaleLowerCase('id-ID').trim();
    return (!q || [row.code,row.name,row.unit].some(v => v.toLocaleLowerCase('id-ID').includes(q))) && (status === 'all' || row.status === status);
  }), [rows,search,status]);
  return <section className="panel modern-panel report-price-panel">
    <div className="data-toolbar"><div><span className="section-kicker">LAPORAN INVENTARIS</span><h2>Posisi Stok & Perubahan Harga</h2><p>Bandingkan dua harga pembelian terakhir setiap barang.</p></div><span className="count-badge">{rows.length} barang</span></div>
    <div className="report-price-tools">
      <label className="search-field"><Search size={17}/><input aria-label="Cari barang" placeholder="Cari kode atau nama barang..." value={search} onChange={event=>setSearch(event.target.value)} /></label>
      <label className="report-filter">Perubahan harga<select aria-label="Filter perubahan harga" value={status} onChange={e=>setStatus(e.target.value)}><option value="all">Semua status</option><option value="up">Harga Naik</option><option value="down">Harga Turun</option><option value="stable">Stabil</option><option value="unknown">Belum ada pembanding</option></select></label>
      {(search || status !== 'all') && <button type="button" className="button-outline" onClick={()=>{setSearch('');setStatus('all')}}><X size={15}/> Reset</button>}
      <span className="count-badge">{visible.length} dari {rows.length} data</span>
    </div>
    <div className="table-scroll"><table><thead><tr><th>Kode Barang</th><th>Nama Barang</th><th>Stok Saat Ini</th><th>Harga Sebelumnya</th><th>Harga Terbaru</th><th>Selisih Harga</th><th>Perubahan</th></tr></thead><tbody>
      {visible.map(row=><tr key={row.id}><td>{row.code}</td><td>{row.name}</td><td>{number(row.stock)} {row.unit}</td><td>{row.previousPrice == null ? '—' : money(row.previousPrice)}</td><td>{money(row.lastPrice)}</td><td className={row.difference == null ? '' : row.difference > 0 ? 'report-diff-up' : row.difference < 0 ? 'report-diff-down' : ''}>{row.difference == null ? '—' : row.difference > 0 ? `+${money(row.difference)}` : row.difference < 0 ? `−${money(Math.abs(row.difference))}` : '—'}</td><td>{row.status === 'up' ? <span className="report-status report-status-up"><ArrowUp size={14}/> Harga Naik</span> : row.status === 'down' ? <span className="report-status report-status-down"><ArrowDown size={14}/> Harga Turun</span> : row.status === 'stable' ? <span className="report-status report-status-stable">—</span> : <span className="report-status report-status-unknown">Belum ada pembanding</span>}</td></tr>)}
      {!visible.length && <tr><td colSpan={7} style={{textAlign:'center',padding:'32px'}}>Tidak ada barang sesuai filter.</td></tr>}
    </tbody></table></div>
    <p className="report-price-note">Selisih harga = harga pembelian terbaru − harga pembelian sebelumnya. Perbandingan hanya menggunakan transaksi Barang Masuk jenis pembelian, bukan Stock Opname. Barang tanpa dua riwayat harga ditandai belum ada pembanding.</p>
  </section>;
}
