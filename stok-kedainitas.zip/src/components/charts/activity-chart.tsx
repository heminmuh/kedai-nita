'use client';

export interface ActivityPoint {
  date: string;
  inbound: number;
  outbound: number;
}

export default function ActivityChart({ values }: { values: ActivityPoint[] }) {
  const max = Math.max(1, ...values.flatMap((x) => [x.inbound, x.outbound]));

  return (
    <div
      className="activity-chart"
      role="img"
      aria-label="Grafik jumlah transaksi masuk dan keluar tujuh hari terakhir"
    >
      <div className="chart-legend">
        <span>● Masuk</span>
        <span>● Keluar</span>
      </div>
      <div className="chart-bars">
        {values.map((v) => (
          <div className="chart-day" key={v.date}>
            <div className="chart-pair">
              <div
                className="chart-bar incoming"
                style={{ height: `${(v.inbound / max) * 100}%` }}
                title={`${v.inbound} masuk`}
              />
              <div
                className="chart-bar outgoing"
                style={{ height: `${(v.outbound / max) * 100}%` }}
                title={`${v.outbound} keluar`}
              />
            </div>
            <small>{v.date.slice(5)}</small>
          </div>
        ))}
      </div>
    </div>
  );
}
