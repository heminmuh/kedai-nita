'use client';
import {useMemo,useState} from 'react';
import {Plus,Search,Image as ImageIcon,Trash2} from 'lucide-react';
import Modal from '@/components/ui/modal';
import {confirmAlert,errorAlert,successAlert} from '@/lib/alerts';
import {uploadNota} from '@/lib/actions/storage';
import {createSupplierReturn} from '@/lib/actions/retur';
import type {ProductOption,SupplierOption} from '@/lib/types';

type ReturnRow={no_transaksi:string;tanggal:string;nama_supplier:string;nama_petugas:string;alasan:string;daftar_barang:string;foto_url:string};
type Item={id_barang:number;jumlah:number};
export default function ReturnManager({rows,products,suppliers}:{rows:ReturnRow[];products:ProductOption[];suppliers:SupplierOption[]}){
 const [open,setOpen]=useState(false),[busy,setBusy]=useState(false),[query,setQuery]=useState(''),[from,setFrom]=useState(''),[to,setTo]=useState('');
 const [items,setItems]=useState<Item[]>([{id_barang:0,jumlah:1}]);const [file,setFile]=useState<File|null>(null);
 const filtered=useMemo(()=>rows.filter(r=>(!from||r.tanggal>=from)&&(!to||r.tanggal<=to)&&[r.no_transaksi,r.nama_supplier,r.nama_petugas,r.daftar_barang,r.alasan].some(v=>v.toLowerCase().includes(query.toLowerCase()))),[rows,query,from,to]);
 async function submit(form:FormData){
  if(busy)return;
  try{
   if(items.some(i=>!i.id_barang||!Number.isFinite(i.jumlah)||i.jumlah<=0))throw new Error('Pilih barang dan jumlah yang valid.');
   if(new Set(items.map(i=>i.id_barang)).size!==items.length)throw new Error('Barang duplikat. Gabungkan jumlahnya.');
   if(!file)throw new Error('Foto bukti retur wajib diunggah.');
   if(!await confirmAlert('Simpan retur ke supplier?','Stok akan langsung berkurang dan tercatat pada Kartu Stok.'))return;
   setBusy(true);
   if(file){const photo=new FormData();photo.set('file',file);form.set('foto_bukti',await uploadNota(photo));}
   form.set('items',JSON.stringify(items));await createSupplierReturn(form);
   await successAlert('Retur berhasil dicatat');window.location.reload();
  }catch(e){await errorAlert(e);}finally{setBusy(false);}
 }
 return <>
 <section className="panel modern-panel"><div className="data-toolbar"><div><span className="section-kicker">PENGEMBALIAN BARANG</span><h2>Retur ke Supplier</h2><p>Catat barang rusak, salah kirim, atau tidak sesuai pesanan.</p></div><button className="primary-action" type="button" onClick={()=>setOpen(true)}><Plus size={17}/> Tambah Retur</button></div></section>
 <section className="panel modern-panel"><div className="data-toolbar"><h2>Riwayat Retur</h2><span className="count-badge">{filtered.length} transaksi</span></div>
 <div className="transaction-filters"><label>Dari tanggal<input type="date" value={from} onChange={e=>setFrom(e.target.value)}/></label><label>Sampai tanggal<input type="date" value={to} onChange={e=>setTo(e.target.value)}/></label><label><span><Search size={15}/> Cari retur</span><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Barang, supplier, petugas..."/></label><button className="button-outline" onClick={()=>{setQuery('');setFrom('');setTo('')}}>Reset</button></div>
 <div className="table-scroll"><table><thead><tr><th>Nomor</th><th>Tanggal</th><th>Supplier</th><th>Barang & Jumlah</th><th>Petugas</th><th>Alasan</th><th>Foto</th></tr></thead><tbody>{filtered.map(r=><tr key={r.no_transaksi}><td>{r.no_transaksi}</td><td>{r.tanggal}</td><td>{r.nama_supplier}</td><td>{r.daftar_barang}</td><td>{r.nama_petugas}</td><td>{r.alasan}</td><td>{r.foto_url?<a href={r.foto_url} target="_blank" rel="noopener noreferrer"><img className="transaction-photo" src={r.foto_url} alt="Bukti retur"/></a>:<span className="photo-empty"><ImageIcon size={15}/> —</span>}</td></tr>)}</tbody></table>{!filtered.length&&<p className="muted" style={{padding:16}}>Belum ada retur.</p>}</div>
 </section>
 <Modal open={open} onClose={()=>!busy&&setOpen(false)} title="Tambah Retur Barang" description="Barang yang dikembalikan akan mengurangi stok gudang.">
 <form action={submit} className="modal-form"><div className="modal-scroll-region"><div className="modal-fields"><label>Supplier <span className="required-star" aria-hidden="true">*</span><select name="id_supplier" required defaultValue=""><option value="" disabled>Pilih supplier</option>{suppliers.map(s=><option value={s.id_supplier} key={s.id_supplier}>{s.nama_supplier}</option>)}</select></label><label>Alasan retur <span className="required-star" aria-hidden="true">*</span><textarea name="alasan" required minLength={3} placeholder="Contoh: kemasan rusak / salah kirim"/></label><label>Foto bukti <span className="required-star" aria-hidden="true">*</span> (1 foto, maks 2 MB)<input type="file" required accept="image/jpeg,image/png,image/webp" onChange={e=>setFile(e.target.files?.[0]??null)}/></label></div>
 <div className="transaction-rows">{items.map((item,i)=><div className="transaction-row" key={i}><label>Barang <span className="required-star" aria-hidden="true">*</span><select required value={item.id_barang} onChange={e=>setItems(prev=>prev.map((v,n)=>i===n?{...v,id_barang:Number(e.target.value)}:v))}><option value={0}>Pilih barang</option>{products.map(p=><option key={p.id_barang} value={p.id_barang}>{p.nama_barang} (stok {p.stok_saat_ini})</option>)}</select></label><label>Jumlah <span className="required-star" aria-hidden="true">*</span><input required type="number" min="0.01" step="any" value={item.jumlah} onChange={e=>setItems(prev=>prev.map((v,n)=>i===n?{...v,jumlah:Number(e.target.value)}:v))}/></label><button type="button" className="table-delete" aria-label="Hapus baris" onClick={()=>setItems(x=>x.filter((_,n)=>n!==i))} disabled={items.length===1}><Trash2 size={16}/></button></div>)}</div>
 <button type="button" className="button-outline" onClick={()=>setItems(x=>[...x,{id_barang:0,jumlah:1}])}>+ Tambah Barang</button>
 </div><div className="modal-footer"><button type="button" className="button-outline" onClick={()=>setOpen(false)} disabled={busy}>Batal</button><button disabled={busy}>{busy?'Menyimpan...':'Simpan Retur'}</button></div></form></Modal>
 </>;
}
