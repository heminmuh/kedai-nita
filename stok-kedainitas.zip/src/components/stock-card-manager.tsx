'use client';

import { useMemo, useState } from 'react';
import { Search, X } from 'lucide-react';
import DataTable from '@/components/ui/data-table';
import type { Row } from '@/lib/types';

export default function StockCardManager({ rows }: { rows: Row[] }) {
  const [search, setSearch] = useState('');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [kind, setKind] = useState('semua');
  const filtered = useMemo(() => rows.filter(row => {
    const date = String(row.waktu ?? '').slice(0, 10);
    if (from && date < from) return false;
    if (to && date > to) return false;
    if (kind === 'retur' && !String(row.referensi ?? '').startsWith('RET-')) return false;
    if (kind === 'keluar' && (String(row.jenis_asli ?? '') !== 'keluar' || String(row.referensi ?? '').startsWith('RET-'))) return false;
    if (!['semua','retur','keluar'].includes(kind) && String(row.jenis_asli ?? '') !== kind) return false;
    const q = search.trim().toLocaleLowerCase('id-ID');
    return !q || ['nama_barang', 'referensi', 'nama_petugas', 'nama_pencatat', 'keterangan'].some(key => String(row[key] ?? '').toLocaleLowerCase('id-ID').includes(q));
  }), [rows, search, from, to, kind]);

  return <section className="panel modern-panel">
    <div className="data-toolbar"><div><span className="section-kicker">RIWAYAT PERGERAKAN</span><h2>Daftar Kartu Stok</h2><p>Telusuri mutasi barang, koreksi opname, serta petugas yang bertanggung jawab.</p></div><span className="count-badge">{filtered.length} dari {rows.length} data</span></div>
    <div className="stock-card-filters">
      <label className="search-field stock-card-search"><Search size={17}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Cari barang, petugas, referensi..." aria-label="Cari kartu stok"/></label>
      <label>Dari tanggal<input aria-label="Tanggal awal" type="date" value={from} onChange={e=>setFrom(e.target.value)}/></label>
      <label>Sampai tanggal<input aria-label="Tanggal akhir" type="date" min={from || undefined} value={to} onChange={e=>setTo(e.target.value)}/></label>
      <label>Jenis<select aria-label="Jenis transaksi" value={kind} onChange={e=>setKind(e.target.value)}><option value="semua">Semua Jenis</option><option value="masuk">Barang Masuk</option><option value="keluar">Barang Keluar</option><option value="adjustment">Stock Opname</option><option value="retur">Retur Barang</option></select></label>
      <button type="button" className="button-outline stock-card-reset" onClick={()=>{setSearch('');setFrom('');setTo('');setKind('semua');}}><X size={16}/> Reset</button>
    </div>
    <DataTable rows={filtered} columns={['waktu_tampil', 'nama_barang', 'jenis', 'referensi', 'jumlah', 'saldo', 'nama_petugas', 'keterangan']}/>
    {!filtered.length && <p className="muted">Tidak ada kartu stok yang sesuai filter.</p>}
  </section>;
}
