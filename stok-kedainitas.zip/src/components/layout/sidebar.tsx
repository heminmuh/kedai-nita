import LogoutButton from './logout-button';
import { NAV_ITEMS } from '@/lib/config/navigation';
import { isOwner } from '@/lib/auth-roles';
import type { Profile } from '@/lib/types';
import SidebarNav from './sidebar-nav';
import { Package2, X, CircleHelp } from 'lucide-react';

export default function Sidebar({ profile, collapsed, closeMobile }: { profile: Profile; collapsed: boolean; closeMobile: () => void }) {
  const owner = isOwner(profile);
  const items = NAV_ITEMS.filter((item) => !item.ownerOnly || owner);
  return (
    <aside className="sidebar nexus-sidebar" aria-label="Navigasi utama">
      <div className="nexus-brand-row"><div className="nexus-logo"><Package2 size={23}/></div><div className="nexus-brand-copy"><strong>Kedai Nita&apos;s</strong><small>WAREHOUSE SYSTEM</small></div><button className="nexus-icon-btn nexus-close-mobile" onClick={closeMobile} aria-label="Tutup sidebar"><X size={20}/></button></div>
      <div className="nexus-menu-label">MAIN MENU</div>
      <SidebarNav items={items} onNavigate={closeMobile} />
      <div className="nexus-sidebar-bottom">
        <div className="nexus-support"><CircleHelp size={18}/><span>Inventory workspace</span></div>
        <div className="nexus-profile"><div className="nexus-avatar">{profile.nama_lengkap.trim().charAt(0).toUpperCase()}</div><div className="nexus-profile-text"><strong>{profile.nama_lengkap}</strong><small>{owner ? 'Owner' : 'Petugas Gudang'}</small></div></div>
        <LogoutButton />
      </div>
    </aside>
  );
}
