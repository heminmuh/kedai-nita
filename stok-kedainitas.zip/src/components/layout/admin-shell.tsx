'use client';

import { useEffect, useState, type ReactNode } from 'react';
import { usePathname } from 'next/navigation';
import { Menu, PanelLeftClose, PanelLeftOpen, ChevronRight, Sun, Moon } from 'lucide-react';
import Sidebar from './sidebar';
import type { Profile } from '@/lib/types';

export default function AdminShell({ profile, children }: { profile: Profile; children: ReactNode }) {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [dark, setDark] = useState(false);
  const pathname = usePathname();
  useEffect(() => { setMobileOpen(false); }, [pathname]);
  useEffect(() => { try { setCollapsed(localStorage.getItem('warehouse-sidebar-collapsed') === 'true'); setDark(localStorage.getItem('warehouse-theme') === 'dark'); } catch {} }, []);
  useEffect(() => { document.body.classList.toggle('warehouse-dark', dark); return () => document.body.classList.remove('warehouse-dark'); }, [dark]);
  useEffect(() => { document.body.style.overflow = mobileOpen ? 'hidden' : ''; return () => { document.body.style.overflow = ''; }; }, [mobileOpen]);
  const toggleCollapsed = () => setCollapsed(v => { try { localStorage.setItem('warehouse-sidebar-collapsed', String(!v)); } catch {} return !v; });
  const toggleDark = () => setDark(v => { try { localStorage.setItem('warehouse-theme', !v ? 'dark' : 'light'); } catch {} return !v; });
  const segments = pathname.split('/').filter(Boolean);
  const current = segments[segments.length - 1]?.replaceAll('-', ' ') || 'Dashboard';
  return (
    <div className={`nexus-shell ${collapsed ? 'nexus-collapsed' : ''} ${mobileOpen ? 'nexus-mobile-open' : ''}`}>
      {mobileOpen && <button className="nexus-overlay" aria-label="Tutup menu navigasi" onClick={() => setMobileOpen(false)} />}
      <Sidebar profile={profile} collapsed={collapsed} closeMobile={() => setMobileOpen(false)} />
      <div className="nexus-workspace">
        <header className="nexus-topbar">
          <div className="nexus-topbar-left">
            <button className="nexus-icon-btn nexus-desktop-toggle" onClick={toggleCollapsed} aria-label={collapsed ? 'Perbesar sidebar' : 'Perkecil sidebar'} title="Toggle sidebar">{collapsed ? <PanelLeftOpen size={20} /> : <PanelLeftClose size={20} />}</button>
            <button className="nexus-icon-btn nexus-mobile-toggle" onClick={() => setMobileOpen(v => !v)} aria-label="Buka menu navigasi"><Menu size={22} /></button>
            <div className="nexus-crumb"><span>Workspace</span><ChevronRight size={14} /><strong>{current}</strong></div>
          </div>
          <div className="nexus-topbar-right">
            <button className="nexus-icon-btn" onClick={toggleDark} aria-label={dark ? 'Mode terang' : 'Mode gelap'} title="Ubah tema">{dark ? <Sun size={19}/> : <Moon size={19}/>}</button>
          </div>
        </header>
        <main className="content nexus-content" id="main-content">{children}</main>
        <footer className="nexus-footer"><span>© {new Date().getFullYear()} Kedai Nita&apos;s Warehouse</span><span>Inventory & Operations</span></footer>
      </div>
    </div>
  );
}
