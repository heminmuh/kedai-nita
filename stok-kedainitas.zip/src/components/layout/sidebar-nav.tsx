'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import type { NavItem } from '@/lib/config/navigation';
import { LayoutDashboard, Package, Truck, Warehouse, ArrowDownToLine, ArrowUpFromLine, ChartNoAxesColumn, ClipboardCheck, BookOpen, FileBarChart, Users, RotateCcw } from 'lucide-react';

const icons = [LayoutDashboard, Package, Truck, Warehouse, ArrowDownToLine, ArrowUpFromLine, ChartNoAxesColumn, ClipboardCheck, BookOpen, FileBarChart, Users];
const navIcons: Record<string, typeof Package> = {
 '/retur': RotateCcw, '/dashboard': icons[0], '/barang': icons[1], '/supplier': icons[2], '/rak': icons[3], '/inbound': icons[4], '/outbound': icons[5], '/stok': icons[6], '/opname': icons[7], '/kartu-stok': icons[8], '/laporan': icons[9], '/pengguna': icons[10]
};
export default function SidebarNav({ items, onNavigate }: { items: NavItem[]; onNavigate?: () => void }) {
  const pathname = usePathname();
  return <nav className="nexus-nav">{items.map((item) => {
    const active = pathname === item.href || pathname.startsWith(`${item.href}/`);
    const Icon = navIcons[item.href] || Package;
    return <Link key={item.href} href={item.href} prefetch={true} onClick={onNavigate} className={`nexus-nav-link ${active ? 'active' : ''}`} aria-current={active ? 'page' : undefined} title={item.label}>
      <Icon size={19} strokeWidth={active ? 2.3 : 1.85}/><span className="nexus-nav-text">{item.label}</span>{active && <span className="nexus-nav-dot"/>}
    </Link>;
  })}</nav>;
}
