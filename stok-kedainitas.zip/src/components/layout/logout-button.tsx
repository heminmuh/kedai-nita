'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { LogOut } from 'lucide-react';
import { logout } from '@/lib/actions/auth';
import { errorAlert, confirmAlert } from '@/lib/alerts';

export default function LogoutButton() {
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  async function handleLogout() {
    if (busy) return;
    const confirmed = await confirmAlert('Yakin ingin keluar?', 'Sesi login akan diakhiri. Pastikan pekerjaan sudah tersimpan.', 'Ya, Keluar');
    if (!confirmed) return;
    setBusy(true);
    try {
      await logout();
      router.replace('/login');
      router.refresh();
    } catch (error) {
      await errorAlert(error, 'Logout gagal');
      setBusy(false);
    }
  }
  return <button type="button" className="nexus-logout" title="Keluar" aria-busy={busy} disabled={busy} onClick={handleLogout}>
    <LogOut size={18}/><span>{busy ? 'Sedang keluar...' : 'Keluar'}</span>
  </button>;
}
