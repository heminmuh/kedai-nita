'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Package } from 'lucide-react';
import { errorAlert } from '@/lib/alerts';
import { login } from '@/lib/actions/auth';
import PasswordField from '@/components/ui/password-field';

export default function LoginForm() {
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  async function submit(form: FormData) {
    if (busy) return;
    setBusy(true);
    try {
      await login(form);
      router.replace('/dashboard');
      router.refresh();
    } catch (error) {
      await errorAlert(error, 'Gagal masuk');
      setBusy(false);
    }
  }
  return (
    <div className="login-split-card">
      <section className="login-pane login-pane-form">
        <div className="login-brand-row">
          <div className="login-brand-icon"><Package size={18} strokeWidth={2.2} /></div>
          <div>
            <p className="login-kicker">AKSES WAREHOUSE</p>
            <strong>Kedai Nita&apos;s</strong>
          </div>
        </div>

        <div className="login-copy">
          <h1>Selamat datang kembali</h1>
          <p>Masuk ke sistem pengelolaan gudang untuk memantau stok, transaksi, dan akses pengguna dengan lebih rapi.</p>
        </div>

        <form action={submit} className="login-form-modern">
          <label>
            <span>Username</span>
            <input name="username" type="text" required minLength={3} maxLength={32} pattern="[a-zA-Z0-9._-]+" placeholder="Contoh: nita" autoComplete="username" autoCapitalize="none" spellCheck={false} />
          </label>
          <PasswordField
            name="password"
            label="Kata sandi"
            required
            autoComplete="current-password"
            placeholder="Masukkan kata sandi"
          />
          <button className="login-submit" disabled={busy} aria-busy={busy} aria-live="polite">
            {busy ? (
              <span className="login-submit-content">
                <span className="login-submit-spinner" aria-hidden="true" />
                <span>Memverifikasi akun...</span>
              </span>
            ) : (
              <span className="login-submit-content">Masuk ke dashboard</span>
            )}
          </button>
        </form>
      </section>

      <section className="login-pane login-pane-visual">
        <div className="login-visual-media">
          <img src="/brand/kedai-nitas-booth.jpg" alt="Booth Kedai Nita's" className="login-visual-image" />
        </div>
        <div className="login-visual-overlay" />
        <div className="login-visual-content">
          <div className="login-visual-badge">
            <Package size={16} strokeWidth={2.2} />
            <span>Kedai Nita&apos;s</span>
          </div>
          <h2>Kelola operasional lebih cepat dan modern.</h2>
          <p>Semua data stok, barang masuk, barang keluar, dan pengguna tersusun dalam satu dashboard yang lebih nyaman digunakan.</p>
        </div>
      </section>
    </div>
  );
}
