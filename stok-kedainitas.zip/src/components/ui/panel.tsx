import type { ReactNode } from 'react';

interface Props {
  title: string;
  badge?: ReactNode;
  children: ReactNode;
}

export default function Panel({ title, badge, children }: Props) {
  return (
    <section className="panel">
      {badge ? (
        <div className="panel-head">
          <h2>{title}</h2>
          {badge}
        </div>
      ) : (
        <h2>{title}</h2>
      )}
      {children}
    </section>
  );
}
