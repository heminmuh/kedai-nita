interface Props {
  eyebrow: string;
  title: string;
  description?: string;
}

export default function PageHeader({
  eyebrow,
  title,
  description = 'Pantau dan kelola aktivitas gudang dengan mudah.',
}: Props) {
  return (
    <header>
      <span className="eyebrow">{eyebrow}</span>
      <h1>{title}</h1>
      <p>{description}</p>
    </header>
  );
}
