'use client';

import { useMemo, useState } from 'react';
import { Search, CalendarDays, Image as ImageIcon } from 'lucide-react';
import type { Row } from '@/lib/types';

type Props = { rows: Row[]; kind: 'inbound' | 'outbound' };
export default function TransactionHistory({ rows, kind }: Props) {
  const [start, setStart] = useState('');
  const [end, setEnd] = useState('');
  const [search, setSearch] = useState('');
  const filtered = useMemo(() => rows.filter(row => {
    const date = String(row.tanggal ?? '').slice(0,10);
    return (!start || date >= start) && (!end || date <= end) &&
      (!search || [row.no_transaksi,row.daftar_barang,row.nama_supplier,row.tujuan,row.catatan].some(v => String(v??'').toLowerCase().includes(search.toLowerCase())));
  }), [rows,start,end,search]);
  return <section className="panel modern-panel transaction-history">
    <div className="data-toolbar"><div><span className="section-kicker">RIWAYAT TRANSAKSI</span><h2>{kind === 'inbound' ? 'Daftar Barang Masuk' : 'Daftar Barang Keluar'}</h2><p>Filter tanggal dan lihat foto bukti penerimaan atau pengeluaran.</p></div><span className="count-badge">{filtered.length} transaksi</span></div>
    <div className="transaction-filters">
      <label><span><CalendarDays size={15}/> Dari tanggal</span><input type="date" value={start} max={end || undefined} onChange={e => setStart(e.target.value)}/></label>
      <label><span><CalendarDays size={15}/> Sampai tanggal</span><input type="date" value={end} min={start || undefined} onChange={e => setEnd(e.target.value)}/></label>
      <label><span><Search size={15}/> Cari</span><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Barang / transaksi..."/></label>
      <button type="button" className="button-outline" onClick={() => {setStart('');setEnd('');setSearch('');}}>Reset filter</button>
    </div>
    <div className="table-scroll"><table><thead><tr><th>No. Transaksi</th><th>Tanggal</th><th>{kind === 'inbound' ? 'Supplier' : 'Tujuan'}</th><th>Barang & Jumlah</th><th>Catatan</th><th>Foto Bukti</th></tr></thead><tbody>
      {filtered.map((row, index) => <tr key={String(row.no_transaksi ?? index)}><td>{String(row.no_transaksi??'—')}</td><td>{String(row.tanggal??'—').slice(0,10)}</td><td>{String(kind === 'inbound' ? row.nama_supplier??'—' : row.tujuan??'—')}</td><td>{String(row.daftar_barang??'—')}</td><td>{String(row.catatan??'—')}</td><td>{typeof row.foto_url === 'string' && row.foto_url ? <a href={row.foto_url} target="_blank" rel="noopener noreferrer" title="Lihat foto bukti"><img className="transaction-photo" src={row.foto_url} alt={`Foto bukti ${String(row.no_transaksi??'transaksi')}`} /></a> : <span className="photo-empty"><ImageIcon size={16}/> Tidak ada foto</span>}</td></tr>)}
    </tbody></table>{filtered.length===0&&<p className="muted" style={{padding:'18px'}}>Belum ada transaksi untuk filter ini.</p>}</div>
  </section>;
}
