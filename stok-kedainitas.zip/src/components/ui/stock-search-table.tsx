'use client';

import { useMemo, useState } from 'react';
import { Search, X } from 'lucide-react';
import type { Row } from '@/lib/types';
import DataTable from './data-table';

const columns = ['kode_barang', 'nama_barang', 'stok_saat_ini', 'stok_minimum', 'satuan', 'lokasi_rak', 'status_stok'];

export default function StockSearchTable({ rows }: { rows: Row[] }) {
  const [query, setQuery] = useState('');
  const filtered = useMemo(() => {
    const keyword = query.trim().toLocaleLowerCase('id-ID');
    if (!keyword) return rows;
    return rows.filter((row) => ['kode_barang', 'nama_barang', 'lokasi_rak', 'status_stok']
      .some((field) => String(row[field] ?? '').toLocaleLowerCase('id-ID').includes(keyword)));
  }, [rows, query]);

  return (
    <>
      <div className="table-tools">
        <label className="search-field">
          <Search size={18} aria-hidden="true" />
          <input type="search" value={query} onChange={(event) => setQuery(event.target.value)}
            placeholder="Cari kode, barang, atau rak..." aria-label="Cari stok barang" />
          {query && <button type="button" className="stock-search-clear" onClick={() => setQuery('')} aria-label="Hapus pencarian"><X size={16}/></button>}
        </label>
        <span className="count-badge">{filtered.length} dari {rows.length} data</span>
      </div>
      <DataTable rows={filtered} columns={columns} />
      {filtered.length === 0 && rows.length > 0 && <p className="muted">Tidak ada barang yang cocok dengan pencarian.</p>}
    </>
  );
}
