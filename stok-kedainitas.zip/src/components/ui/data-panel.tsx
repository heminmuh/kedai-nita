import type { ReactNode } from 'react';
import type { Row } from '@/lib/types';
import DataTable from './data-table';
import Panel from './panel';

interface Props {
  title: string;
  rows: Row[];
  columns: string[];
  children?: ReactNode;
}

/** Panel berisi tabel + badge jumlah data. */
export default function DataPanel({ title, rows, columns, children }: Props) {
  return (
    <Panel title={title} badge={<span className="pill">{rows.length} data</span>}>
      <DataTable rows={rows} columns={columns} />
      {children}
    </Panel>
  );
}
