'use client';
import { useState, type ReactNode } from 'react';
import { Plus } from 'lucide-react';
import Modal from './modal';
export default function FormModal({title,description,children}:{title:string;description?:string;children:ReactNode}){
 const [open,setOpen]=useState(false);
 return <><div className="form-launch"><div><span className="section-kicker">AKSI CEPAT</span><h2>{title}</h2><p>{description??'Buat pencatatan baru lewat formulir.'}</p></div><button onClick={()=>setOpen(true)} className="primary-action"><Plus size={17}/> {title}</button></div><Modal open={open} onClose={()=>setOpen(false)} title={title} description={description}>{open&&children}</Modal></>;
}
