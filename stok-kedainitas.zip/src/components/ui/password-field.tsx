'use client';

import { useId, useState, type InputHTMLAttributes } from 'react';
import { Eye, EyeOff } from 'lucide-react';

type Props = InputHTMLAttributes<HTMLInputElement> & {
  label?: string;
  hint?: string;
};

export default function PasswordField({ label, hint, id, className = '', ...props }: Props) {
  const generatedId = useId();
  const fieldId = id ?? generatedId;
  const [visible, setVisible] = useState(false);

  const input = (
    <div className={`password-field ${className}`.trim()}>
      <input id={fieldId} {...props} type={visible ? 'text' : 'password'} />
      <button
        type="button"
        className="password-toggle"
        aria-label={visible ? 'Sembunyikan kata sandi' : 'Tampilkan kata sandi'}
        aria-pressed={visible}
        onClick={() => setVisible((v) => !v)}
      >
        {visible ? <EyeOff size={18} /> : <Eye size={18} />}
      </button>
    </div>
  );

  if (!label) return input;

  return (
    <label>
      <span>{label}{props.required ? <span className="required-star" aria-hidden="true"> *</span> : null}</span>
      {input}
      {hint ? <small className="field-hint">{hint}</small> : null}
    </label>
  );
}
