interface Props {
  label: string;
  value: number | string;
  hint: string;
}

export default function StatCard({ label, value, hint }: Props) {
  return (
    <div className="stat">
      <span>{label}</span>
      <strong>{value}</strong>
      <small>{hint}</small>
    </div>
  );
}
