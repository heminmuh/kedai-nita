import type { Row } from '@/lib/types';
import type { ReactNode } from 'react';

interface Props {
  rows: Row[];
  columns: string[];
  action?: (row: Row) => ReactNode;
}

export default function DataTable({ rows, columns, action }: Props) {
  return (
    <div className="table-scroll">
      <table>
        <thead>
          <tr>
            {columns.map((c) => (
              <th key={c}>{({'isi_rak':'Isi Rak (dari Barang)', 'jumlah_jenis_barang':'Jenis Barang', 'daftar_barang':'Barang & Jumlah', 'nama_supplier':'Supplier', 'lokasi_rak':'Lokasi Rak', 'status_stok':'Status Stok', 'diajukan_oleh':'Diajukan Oleh', 'barang_diperiksa':'Hasil Perhitungan'} as Record<string,string>)[c] ?? c.replaceAll('_', ' ')}</th>
            ))}
            {action && <th>Aksi</th>}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr key={i}>
              {columns.map((c) => (
                <td key={c}>{row[c] == null ? '—' : c === 'status_stok' ? <span className={String(row[c]) === 'Menipis' ? 'stock-status-low' : 'stock-status-safe'}>{String(row[c])}</span> : String(row[c])}</td>
              ))}
              {action && <td>{action(row)}</td>}
            </tr>
          ))}
        </tbody>
      </table>
      {!rows.length && <p className="muted">Belum ada data.</p>}
    </div>
  );
}
