-- Koreksi data contoh Kedai Nita's yang sudah dimasukkan.
-- Jalankan SEKALI di Supabase SQL Editor setelah membaca README-KOREKSI-DATA.md.
-- Hanya menyentuh baris dengan penanda lama atau kode barang yang cocok.
-- Tidak membuat akun Auth dan tidak menyentuh data transaksi di luar batch awal.
BEGIN;

DO $fix$
DECLARE
  v_actor bigint;
  v_staff bigint;
  v_out bigint;
  v_no text;
  v_old text;
  v_new text;
  v_record record;
  v_product bigint;
  v_batch bigint;
  v_balance numeric;
  v_expected numeric;
  v_quantity numeric;
  v_op bigint;
BEGIN
  -- Hanya jalankan pada data awal yang memang memiliki marker terdahulu.
  IF NOT EXISTS (SELECT 1 FROM public.inbound WHERE no_transaksi LIKE 'DEMO-IN-%') THEN
    RAISE EXCEPTION 'Tidak ditemukan transaksi awal dengan penanda lama. Koreksi dibatalkan agar data lain aman.';
  END IF;

  -- Deteksi konflik sebelum mengubah nomor transaksi.
  IF EXISTS (
    SELECT 1 FROM public.inbound a JOIN public.inbound b
      ON b.no_transaksi = replace(a.no_transaksi,'DEMO-IN-','AWAL-IN-')
    WHERE a.no_transaksi LIKE 'DEMO-IN-%'
  ) OR EXISTS (
    SELECT 1 FROM public.outbound a JOIN public.outbound b
      ON b.no_transaksi = replace(a.no_transaksi,'DEMO-OUT-','AWAL-OUT-')
    WHERE a.no_transaksi LIKE 'DEMO-OUT-%'
  ) OR EXISTS (
    SELECT 1 FROM public.stock_opname a JOIN public.stock_opname b
      ON b.no_transaksi = replace(a.no_transaksi,'DEMO-OP-','AWAL-OP-')
    WHERE a.no_transaksi LIKE 'DEMO-OP-%'
  ) THEN
    RAISE EXCEPTION 'Nomor transaksi pengganti sudah digunakan; koreksi dibatalkan.';
  END IF;

  -- Pertahankan riwayat: perbarui nomor transaksi dan referensi kartu stok bersamaan.
  UPDATE public.kartu_stok SET referensi = replace(referensi,'DEMO-IN-','AWAL-IN-') WHERE referensi LIKE 'DEMO-IN-%';
  UPDATE public.kartu_stok SET referensi = replace(referensi,'DEMO-OUT-','AWAL-OUT-') WHERE referensi LIKE 'DEMO-OUT-%';
  UPDATE public.kartu_stok SET referensi = replace(referensi,'DEMO-OP-','AWAL-OP-') WHERE referensi LIKE 'DEMO-OP-%';
  UPDATE public.inbound SET no_transaksi = replace(no_transaksi,'DEMO-IN-','AWAL-IN-'),
    catatan = 'Penerimaan stok awal' WHERE no_transaksi LIKE 'DEMO-IN-%';
  UPDATE public.outbound SET no_transaksi = replace(no_transaksi,'DEMO-OUT-','AWAL-OUT-'),
    catatan = 'Pengeluaran stok operasional' WHERE no_transaksi LIKE 'DEMO-OUT-%';
  UPDATE public.stock_opname SET no_transaksi = replace(no_transaksi,'DEMO-OP-','AWAL-OP-'),
    catatan = 'Pemeriksaan persediaan' WHERE no_transaksi LIKE 'DEMO-OP-%';

  UPDATE public.kartu_stok SET keterangan = 'Penerimaan stok awal' WHERE keterangan = 'DATA DEMO — barang masuk';
  UPDATE public.kartu_stok SET keterangan = 'Pengeluaran stok operasional' WHERE keterangan = 'DATA DEMO — barang keluar';
  UPDATE public.stock_opname_detail SET alasan = 'Perlu verifikasi hasil perhitungan' WHERE alasan = 'DATA DEMO — hasil hitung sementara';
  UPDATE public.lokasi_rak SET keterangan = replace(keterangan,'; contoh','') WHERE kode_rak IN ('RK-A01','RK-A02','RK-B01','RK-C01') AND keterangan LIKE '%; contoh';

  UPDATE public.supplier SET nama_supplier='Distributor Bahan Minuman',alamat=NULL WHERE nama_supplier='DEMO - Distributor Bahan Minuman';
  UPDATE public.supplier SET nama_supplier='Kemasan Nusantara',alamat=NULL WHERE nama_supplier='DEMO - Kemasan Nusantara';
  UPDATE public.supplier SET nama_supplier='Frozen Food & Ice Cream',alamat=NULL WHERE nama_supplier='DEMO - Frozen Food & Ice Cream';
  UPDATE public.supplier SET nama_supplier='Grosir Snack & Topping',alamat=NULL WHERE nama_supplier='DEMO - Grosir Snack & Topping';

  -- Petugas yang sudah terdaftar mengajukan stock opname yang berstatus menunggu.
  SELECT id_pengguna INTO v_staff FROM public.pengguna WHERE peran='petugas' AND aktif=true
    ORDER BY id_pengguna LIMIT 1;
  IF v_staff IS NOT NULL THEN
    UPDATE public.stock_opname SET id_pengguna=v_staff,
      catatan='Pengajuan pemeriksaan stok oleh petugas'
    WHERE no_transaksi LIKE 'AWAL-OP-%' AND status='menunggu';
  END IF;

  -- Buat beberapa stok menipis melalui pengeluaran riil dalam ledger,
  -- tetapi HANYA bila stok masih sama persis seperti kondisi setelah seed awal.
  -- Kalau sudah ada aktivitas operasional, dilewati agar tidak mengubah data berjalan.
  IF (SELECT stok_saat_ini FROM public.barang WHERE kode_barang='BHN-002')=16
    AND (SELECT stok_saat_ini FROM public.barang WHERE kode_barang='KMS-001')=250
    AND (SELECT stok_saat_ini FROM public.barang WHERE kode_barang='ESK-002')=14
    AND NOT EXISTS (SELECT 1 FROM public.outbound WHERE no_transaksi='AWAL-OUT-STOK-MENIPIS') THEN

    SELECT id_pengguna INTO v_actor FROM public.pengguna WHERE aktif=true AND peran='admin' ORDER BY id_pengguna LIMIT 1;
    IF v_actor IS NULL THEN RAISE EXCEPTION 'Akun admin aktif tidak ditemukan.'; END IF;
    INSERT INTO public.outbound(no_transaksi,tanggal,tujuan,catatan,id_pengguna)
      VALUES('AWAL-OUT-STOK-MENIPIS',current_date,'Kebutuhan booth dan operasional','Pengeluaran barang untuk operasional',coalesce(v_staff,v_actor))
      RETURNING id_outbound INTO v_out;

    FOR v_record IN SELECT * FROM (VALUES
      ('BHN-002'::text,10::numeric),('KMS-001',110::numeric),('ESK-002',6::numeric)
    ) AS chosen(code,qty) LOOP
      SELECT id_barang INTO v_product FROM public.barang WHERE kode_barang=v_record.code;
      SELECT id_inbound_detail INTO v_batch FROM public.inbound_detail WHERE id_barang=v_product
        AND sisa_jumlah >= v_record.qty ORDER BY id_inbound_detail LIMIT 1;
      IF v_batch IS NULL THEN RAISE EXCEPTION 'Batch tidak mencukupi untuk %',v_record.code; END IF;
      UPDATE public.inbound_detail SET sisa_jumlah=sisa_jumlah-v_record.qty WHERE id_inbound_detail=v_batch;
      UPDATE public.barang SET stok_saat_ini=stok_saat_ini-v_record.qty WHERE id_barang=v_product
        RETURNING stok_saat_ini INTO v_balance;
      INSERT INTO public.outbound_detail(id_outbound,id_barang,id_inbound_detail,jumlah)
        VALUES(v_out,v_product,v_batch,v_record.qty);
      INSERT INTO public.kartu_stok(id_barang,jenis,referensi,jumlah,saldo,keterangan,id_pengguna)
        VALUES(v_product,'keluar','AWAL-OUT-STOK-MENIPIS',-v_record.qty,v_balance,
          'Pengeluaran operasional',coalesce(v_staff,v_actor));
    END LOOP;
  END IF;
END;
$fix$;
COMMIT;

-- Cek hasil:
SELECT kode_barang,nama_barang,stok_saat_ini,stok_minimum,
  CASE WHEN stok_saat_ini <= stok_minimum THEN 'Stok menipis' ELSE 'Aman' END AS kondisi
FROM public.barang ORDER BY kode_barang;
SELECT o.no_transaksi,o.status,p.nama_lengkap,p.peran,o.catatan
FROM public.stock_opname o JOIN public.pengguna p ON p.id_pengguna=o.id_pengguna
ORDER BY o.id_opname DESC;
