-- KEDAI NITA'S: RESET DATA OPERASIONAL
-- PERINGATAN: HAPUS PERMANEN SEMUA DATA TRANSAKSI, STOK, MASTER DAN PROFIL.
-- Jalankan hanya di project Supabase yang benar, SETELAH backup.
-- Tidak menghapus auth.users (Supabase Auth); lihat README-RESET.
-- Tidak menghapus schema, functions, policies, ataupun Storage objects.
BEGIN;
TRUNCATE TABLE
  public.retur_supplier_detail,
  public.retur_supplier,
  public.outbound_detail,
  public.inbound_detail,
  public.stock_opname_detail,
  public.kartu_stok,
  public.stock_opname,
  public.outbound,
  public.inbound,
  public.barang,
  public.lokasi_rak,
  public.supplier,
  public.pengguna
RESTART IDENTITY RESTRICT;
-- Restart transaction numbering as part of the fresh start.
ALTER SEQUENCE public.transaction_serial RESTART WITH 1;
COMMIT;
