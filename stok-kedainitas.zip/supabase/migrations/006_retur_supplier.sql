-- Retur ke supplier: mengurangi stok secara atomik dan mencatat kartu stok.
-- Jalankan sekali di SQL Editor setelah migrasi sebelumnya.
create table if not exists public.retur_supplier (
  id_retur bigint generated always as identity primary key,
  no_transaksi text not null unique,
  tanggal date not null default current_date,
  id_supplier bigint not null references public.supplier(id_supplier),
  alasan text not null,
  foto_bukti text,
  id_pengguna bigint not null references public.pengguna(id_pengguna),
  dibuat_pada timestamptz not null default now()
);
create table if not exists public.retur_supplier_detail (
  id_detail bigint generated always as identity primary key,
  id_retur bigint not null references public.retur_supplier(id_retur),
  id_barang bigint not null references public.barang(id_barang),
  jumlah numeric(12,2) not null check (jumlah > 0)
);
create index if not exists retur_supplier_tanggal_idx on public.retur_supplier(tanggal desc);
alter table public.retur_supplier enable row level security;
alter table public.retur_supplier_detail enable row level security;
drop policy if exists "retur active read" on public.retur_supplier;
create policy "retur active read" on public.retur_supplier for select to authenticated using (public.current_profile_id() is not null);
drop policy if exists "retur detail active read" on public.retur_supplier_detail;
create policy "retur detail active read" on public.retur_supplier_detail for select to authenticated using (public.current_profile_id() is not null);

create or replace function public.create_retur_supplier(p_supplier bigint,p_alasan text,p_items jsonb,p_foto_bukti text default null)
returns text language plpgsql security definer set search_path = '' as $$
declare v_user bigint; v_id bigint; v_no text; v_item jsonb; v_bid bigint; v_qty numeric; v_balance numeric; v_left numeric; v_take numeric; v_batch record;
begin
 v_user := public.current_profile_id();
 if v_user is null then raise exception 'Sesi tidak valid'; end if;
 if p_supplier is null or not exists(select 1 from public.supplier where id_supplier=p_supplier and aktif=true) then raise exception 'Supplier tidak valid'; end if;
 if length(trim(coalesce(p_alasan,''))) < 3 then raise exception 'Alasan retur minimal 3 karakter'; end if;
 if jsonb_typeof(p_items) is distinct from 'array' or jsonb_array_length(p_items)=0 then raise exception 'Barang retur wajib diisi'; end if;
 if (select count(*) from jsonb_array_elements(p_items)) <> (select count(distinct (x->>'id_barang')) from jsonb_array_elements(p_items) x) then raise exception 'Barang duplikat tidak diizinkan'; end if;
 perform pg_advisory_xact_lock(726318);
 v_no:=public.next_transaction('RET');
 insert into public.retur_supplier(no_transaksi,id_supplier,alasan,foto_bukti,id_pengguna) values(v_no,p_supplier,trim(p_alasan),p_foto_bukti,v_user) returning id_retur into v_id;
 for v_item in select * from jsonb_array_elements(p_items) loop
   v_bid := (v_item->>'id_barang')::bigint; v_qty := (v_item->>'jumlah')::numeric;
   if v_bid is null or v_qty is null or v_qty<=0 then raise exception 'Jumlah retur tidak valid'; end if;
   update public.barang set stok_saat_ini=stok_saat_ini-v_qty where id_barang=v_bid and aktif and stok_saat_ini>=v_qty returning stok_saat_ini into v_balance;
   if not found then raise exception 'Stok tidak cukup atau barang tidak aktif'; end if;
   v_left:=v_qty;
   for v_batch in select id_inbound_detail,sisa_jumlah from public.inbound_detail where id_barang=v_bid and sisa_jumlah>0 order by tgl_kedaluwarsa asc nulls last,id_inbound_detail for update loop
     exit when v_left<=0;
     v_take:=least(v_left,v_batch.sisa_jumlah);
     update public.inbound_detail set sisa_jumlah=sisa_jumlah-v_take where id_inbound_detail=v_batch.id_inbound_detail;
     v_left:=v_left-v_take;
   end loop;
   if v_left>0 then raise exception 'Stok batch untuk retur tidak cukup'; end if;
   insert into public.retur_supplier_detail(id_retur,id_barang,jumlah) values(v_id,v_bid,v_qty);
   insert into public.kartu_stok(id_barang,jenis,referensi,jumlah,saldo,keterangan,id_pengguna)
     values(v_bid,'keluar',v_no,-v_qty,v_balance,'Retur supplier: '||trim(p_alasan),v_user);
 end loop;
 return v_no;
end $$;
revoke all on function public.create_retur_supplier(bigint,text,jsonb,text) from public,anon;
grant execute on function public.create_retur_supplier(bigint,text,jsonb,text) to authenticated;
