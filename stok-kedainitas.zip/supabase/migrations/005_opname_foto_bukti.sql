-- Jalankan setelah 004_opname_petugas_only.sql.
-- Foto bukti privat, satu foto per transaksi; petugas diidentifikasi dari sesi Supabase.
alter table public.stock_opname add column if not exists foto_bukti text;
create or replace function public.create_opname(p_catatan text,p_items jsonb,p_foto_bukti text) returns text language plpgsql security definer set search_path='' as $$
declare v_user bigint;v_role text;v_no text;v_id bigint;v_item jsonb;v_current numeric;v_physical numeric;v_reason text;
begin
v_user:=public.current_profile_id();if v_user is null then raise exception 'Unauthorized';end if;
select peran into v_role from public.pengguna where id_pengguna=v_user and aktif=true;
if v_role is distinct from 'petugas' then raise exception 'Hanya petugas yang dapat mengajukan opname';end if;
if p_foto_bukti is null or length(trim(p_foto_bukti))=0 then raise exception 'Foto bukti wajib diunggah';end if;
if not exists (select 1 from storage.objects where bucket_id='nota' and name=p_foto_bukti and owner_id=(select auth.uid())::text) then raise exception 'Foto bukti tidak valid atau bukan milik pengaju';end if;
if jsonb_typeof(p_items)<>'array' or jsonb_array_length(p_items)=0 then raise exception 'Items required';end if;
v_no:=public.next_transaction('OP');insert into public.stock_opname(no_transaksi,catatan,id_pengguna,foto_bukti) values(v_no,p_catatan,v_user,p_foto_bukti) returning id_opname into v_id;
for v_item in select * from jsonb_array_elements(p_items) loop
select stok_saat_ini into v_current from public.barang where id_barang=(v_item->>'id_barang')::bigint;if not found then raise exception 'Barang tidak ditemukan';end if;
v_physical:=(v_item->>'stok_fisik')::numeric;v_reason:=nullif(trim(v_item->>'alasan'),'');if v_physical is null or v_physical<0 then raise exception 'Stok fisik tidak valid';end if;if v_physical<>v_current and v_reason is null then raise exception 'Alasan selisih wajib';end if;
insert into public.stock_opname_detail(id_opname,id_barang,stok_sistem,stok_fisik,selisih,alasan) values(v_id,(v_item->>'id_barang')::bigint,v_current,v_physical,v_physical-v_current,v_reason);
end loop;return v_no;end$$;

revoke execute on function public.create_opname(text,jsonb,text) from public, anon;
grant execute on function public.create_opname(text,jsonb,text) to authenticated;
