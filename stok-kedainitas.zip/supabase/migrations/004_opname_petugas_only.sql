-- Batasi pengajuan hanya untuk petugas, termasuk pemanggilan RPC langsung.
-- Mengubah fungsi dengan menjaga logika perhitungan lama.
create or replace function public.create_opname(p_catatan text,p_items jsonb) returns text language plpgsql security definer set search_path='' as $$
declare v_user bigint;v_role text;v_no text;v_id bigint;v_item jsonb;v_current numeric;v_physical numeric;v_reason text;
begin
v_user:=public.current_profile_id();if v_user is null then raise exception 'Unauthorized';end if;
select peran into v_role from public.pengguna where id_pengguna=v_user and aktif=true;
if v_role is distinct from 'petugas' then raise exception 'Hanya petugas yang dapat mengajukan opname';end if;
if jsonb_typeof(p_items)<>'array' or jsonb_array_length(p_items)=0 then raise exception 'Items required';end if;
v_no:=public.next_transaction('OP');insert into public.stock_opname(no_transaksi,catatan,id_pengguna) values(v_no,p_catatan,v_user) returning id_opname into v_id;
for v_item in select * from jsonb_array_elements(p_items) loop
select stok_saat_ini into v_current from public.barang where id_barang=(v_item->>'id_barang')::bigint;if not found then raise exception 'Barang tidak ditemukan';end if;
v_physical:=(v_item->>'stok_fisik')::numeric;v_reason:=nullif(trim(v_item->>'alasan'),'');if v_physical is null or v_physical<0 then raise exception 'Stok fisik tidak valid';end if;if v_physical<>v_current and v_reason is null then raise exception 'Alasan selisih wajib';end if;
insert into public.stock_opname_detail(id_opname,id_barang,stok_sistem,stok_fisik,selisih,alasan) values(v_id,(v_item->>'id_barang')::bigint,v_current,v_physical,v_physical-v_current,v_reason);
end loop;return v_no;end$$;
