-- Jalankan satu kali di Supabase SQL Editor bila project sudah menggunakan 001_init.sql.
-- Delete hanya admin aktif; proteksi relasi juga dijaga oleh foreign keys.
create policy "owner delete" on public.barang for delete to authenticated using (public.is_owner());
create policy "owner delete" on public.lokasi_rak for delete to authenticated using (public.is_owner());
create policy "owner delete" on public.supplier for delete to authenticated using (public.is_owner());
