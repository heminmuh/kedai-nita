-- Jalankan satu kali via Supabase SQL Editor sebelum menggunakan foto Barang Keluar.
-- Kolom existing inbound.foto_nota dan bucket privat nota sudah tersedia.
alter table public.outbound add column if not exists foto_nota text;

create or replace function public.create_outbound(p_tujuan text,p_catatan text,p_items jsonb,p_foto_nota text default null) returns text language plpgsql security definer set search_path='' as $$
declare v_user bigint;v_id bigint;v_no text;v_item jsonb;v_bid bigint;v_qty numeric;v_left numeric;v_take numeric;v_batch record;v_balance numeric;
begin
v_user:=public.current_profile_id();if v_user is null then raise exception 'Unauthorized';end if;
if nullif(trim(p_tujuan),'') is null or jsonb_typeof(p_items)<>'array' or jsonb_array_length(p_items)=0 then raise exception 'Tujuan dan items wajib';end if;
-- Serialize stock changes across transactions, preventing concurrent overselling.
perform pg_advisory_xact_lock(726318);
v_no:=public.next_transaction('OUT');insert into public.outbound(no_transaksi,tujuan,catatan,foto_nota,id_pengguna) values(v_no,p_tujuan,p_catatan,p_foto_nota,v_user) returning id_outbound into v_id;
for v_item in select * from jsonb_array_elements(p_items) loop
v_bid:=(v_item->>'id_barang')::bigint;v_qty:=(v_item->>'jumlah')::numeric;if v_qty is null or v_qty<=0 then raise exception 'Jumlah tidak valid';end if;
update public.barang set stok_saat_ini=stok_saat_ini-v_qty where id_barang=v_bid and aktif=true and stok_saat_ini>=v_qty returning stok_saat_ini into v_balance;if not found then raise exception 'Stok tidak cukup atau barang tidak aktif';end if;
v_left:=v_qty;
for v_batch in select id_inbound_detail,sisa_jumlah from public.inbound_detail where id_barang=v_bid and sisa_jumlah>0 order by tgl_kedaluwarsa asc nulls last,id_inbound_detail asc for update loop
exit when v_left<=0;v_take:=least(v_left,v_batch.sisa_jumlah);update public.inbound_detail set sisa_jumlah=sisa_jumlah-v_take where id_inbound_detail=v_batch.id_inbound_detail;insert into public.outbound_detail(id_outbound,id_barang,id_inbound_detail,jumlah) values(v_id,v_bid,v_batch.id_inbound_detail,v_take);v_left:=v_left-v_take;
end loop;if v_left>0 then raise exception 'Batch tidak cukup untuk barang %',v_bid;end if;
insert into public.kartu_stok(id_barang,jenis,referensi,jumlah,saldo,id_pengguna) values(v_bid,'keluar',v_no,-v_qty,v_balance,v_user);
end loop;return v_no;end$$;

revoke execute on function public.create_outbound(text,text,jsonb,text) from public, anon;
grant execute on function public.create_outbound(text,text,jsonb,text) to authenticated;
-- Hindari endpoint RPC lama agar tidak ada jalur pengeluaran dengan signature berbeda.
drop function if exists public.create_outbound(text,text,jsonb);
