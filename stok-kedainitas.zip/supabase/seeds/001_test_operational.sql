-- DATA UJI OPERASIONAL Kedai Nita's. Bukan catatan transaksi aktual. Jalankan setelah empat akun dibuat.
-- Requires 001_init.sql migration and at least one real row in public.pengguna.
-- Safety: refuses to run when any warehouse master/transaction table has data.
-- Semua jumlah/harga/nama supplier di bawah bersifat simulasi, bukan data hasil audit.
BEGIN;
DO $seed$
DECLARE
  v_actor bigint;
  v_nita bigint; v_haemin bigint; v_fitri bigint; v_pandu bigint;
  v_in bigint;
  v_out bigint;
  v_op bigint;
  v_item jsonb;
  v_product bigint;
  v_supplier bigint;
  v_batch bigint;
  v_quantity numeric;
  v_current numeric;
  v_idx int;
  v_trans text;
  v_all jsonb;
  v_outgoing jsonb;
  v_remaining numeric;
BEGIN
  IF EXISTS (SELECT 1 FROM public.barang) OR EXISTS (SELECT 1 FROM public.supplier)
     OR EXISTS (SELECT 1 FROM public.lokasi_rak) OR EXISTS (SELECT 1 FROM public.inbound)
     OR EXISTS (SELECT 1 FROM public.inbound_detail) OR EXISTS (SELECT 1 FROM public.outbound)
     OR EXISTS (SELECT 1 FROM public.outbound_detail) OR EXISTS (SELECT 1 FROM public.stock_opname)
     OR EXISTS (SELECT 1 FROM public.stock_opname_detail) OR EXISTS (SELECT 1 FROM public.kartu_stok)
     OR EXISTS (SELECT 1 FROM public.retur_supplier)
  THEN RAISE EXCEPTION 'Seed dibatalkan: tabel warehouse sudah berisi data. Gunakan database development kosong agar data asli tidak tercampur.';
  END IF;

  SELECT id_pengguna INTO v_nita FROM public.pengguna WHERE username='nita' AND peran='admin' AND aktif=true;
  SELECT id_pengguna INTO v_haemin FROM public.pengguna WHERE username='haemin' AND peran='petugas' AND aktif=true;
  SELECT id_pengguna INTO v_fitri FROM public.pengguna WHERE username='fitri' AND peran='petugas' AND aktif=true;
  SELECT id_pengguna INTO v_pandu FROM public.pengguna WHERE username='pandu' AND peran='petugas' AND aktif=true;
  IF v_nita IS NULL OR v_haemin IS NULL OR v_fitri IS NULL OR v_pandu IS NULL THEN
    RAISE EXCEPTION 'Buat empat profil nita, haemin, fitri, pandu terlebih dahulu.';
  END IF;
  v_actor := v_haemin;
  

  INSERT INTO public.lokasi_rak (kode_rak,nama_rak,jenis,keterangan) VALUES
  ('RK-A01','Rak Bahan Kering','Gudang kering','Bubuk dan bahan kering'),
  ('RK-A02','Rak Kemasan','Gudang kering','Cup, sedotan, dan kemasan'),
  ('RK-B01','Chiller Minuman','Chiller','Bahan dingin'),
  ('RK-C01','Freezer Es Krim','Freezer','Penyimpanan beku');

  INSERT INTO public.supplier (nama_supplier,kontak,telepon,alamat) VALUES
  ('Distributor Bahan Minuman','Tim Pembelian',NULL,'Alamat belum diisi'),
  ('Kemasan Nusantara','Tim Penjualan',NULL,'Alamat belum diisi'),
  ('Frozen Food & Ice Cream','Tim Penjualan',NULL,'Alamat belum diisi'),
  ('Grosir Snack & Topping','Tim Pembelian',NULL,'Alamat belum diisi');

  -- Fixtures grouped by storage/supplier; prices in IDR per unit (fictional).
  v_all := '[
    {"code":"BHN-001","name":"Bubuk Cokelat","category":"Bahan Minuman","unit":"kg","min":10,"price":82000,"rack":"RK-A01","supplier":1,"qty":35,"expiry":"2027-09-01"},
    {"code":"BHN-002","name":"Bubuk Matcha","category":"Bahan Minuman","unit":"kg","min":8,"price":125000,"rack":"RK-A01","supplier":1,"qty":22,"expiry":"2027-07-15"},
    {"code":"BHN-003","name":"Sirup Vanilla","category":"Bahan Minuman","unit":"botol","min":12,"price":42000,"rack":"RK-A01","supplier":1,"qty":38,"expiry":"2027-04-30"},
    {"code":"BHN-004","name":"Susu UHT Full Cream","category":"Bahan Minuman","unit":"liter","min":40,"price":21000,"rack":"RK-B01","supplier":1,"qty":75,"expiry":"2027-02-28"},
    {"code":"KMS-001","name":"Cup Plastik 16 oz","category":"Kemasan","unit":"pcs","min":150,"price":850,"rack":"RK-A02","supplier":2,"qty":350,"expiry":null},
    {"code":"KMS-002","name":"Tutup Cup Dome","category":"Kemasan","unit":"pcs","min":150,"price":450,"rack":"RK-A02","supplier":2,"qty":300,"expiry":null},
    {"code":"KMS-003","name":"Sedotan Besar","category":"Kemasan","unit":"pcs","min":200,"price":200,"rack":"RK-A02","supplier":2,"qty":500,"expiry":null},
    {"code":"ESK-001","name":"Es Krim Vanilla","category":"Es Krim","unit":"tub","min":10,"price":135000,"rack":"RK-C01","supplier":3,"qty":28,"expiry":"2027-01-31"},
    {"code":"ESK-002","name":"Es Krim Cokelat","category":"Es Krim","unit":"tub","min":10,"price":138000,"rack":"RK-C01","supplier":3,"qty":20,"expiry":"2027-01-31"},
    {"code":"TPG-001","name":"Meses Cokelat","category":"Topping","unit":"kg","min":10,"price":52000,"rack":"RK-A01","supplier":4,"qty":24,"expiry":"2027-05-31"},
    {"code":"TPG-002","name":"Choco Chips","category":"Topping","unit":"kg","min":8,"price":68000,"rack":"RK-A01","supplier":4,"qty":18,"expiry":"2027-05-31"},
    {"code":"SNK-001","name":"Tempura Mix","category":"Snack","unit":"pack","min":25,"price":23000,"rack":"RK-C01","supplier":4,"qty":60,"expiry":"2027-03-31"}
  ]'::jsonb;

  FOR v_item IN SELECT value FROM jsonb_array_elements(v_all) LOOP
    INSERT INTO public.barang(kode_barang,nama_barang,kategori,satuan,stok_minimum,stok_saat_ini,harga_beli_terakhir,id_rak,id_supplier_utama)
    VALUES(v_item->>'code',v_item->>'name',v_item->>'category',v_item->>'unit',(v_item->>'min')::numeric,0,(v_item->>'price')::numeric,
      (SELECT id_rak FROM public.lokasi_rak WHERE kode_rak=v_item->>'rack'),
      (SELECT id_supplier FROM public.supplier ORDER BY id_supplier OFFSET ((v_item->>'supplier')::int - 1) LIMIT 1));
  END LOOP;

  -- Four incoming receipts, one per supplier category.
  FOR v_idx IN 1..4 LOOP
    v_actor := CASE v_idx WHEN 1 THEN v_haemin WHEN 2 THEN v_fitri WHEN 3 THEN v_pandu ELSE v_haemin END;
    v_trans := 'IN-' || to_char(current_date-(7-v_idx),'YYYYMMDD') || '-' || lpad(v_idx::text,3,'0');
    SELECT id_supplier INTO v_supplier FROM public.supplier ORDER BY id_supplier OFFSET (v_idx-1) LIMIT 1;
    INSERT INTO public.inbound(no_transaksi,tanggal,id_supplier,jenis,catatan,id_pengguna)
    VALUES(v_trans,current_date-(7-v_idx),v_supplier,'pembelian','Penerimaan stok awal',v_actor)
    RETURNING id_inbound INTO v_in;

    FOR v_item IN SELECT value FROM jsonb_array_elements(v_all) WHERE (value->>'supplier')::int = v_idx LOOP
      SELECT id_barang INTO v_product FROM public.barang WHERE kode_barang=v_item->>'code';
      v_quantity := (v_item->>'qty')::numeric;
      INSERT INTO public.inbound_detail(id_inbound,id_barang,jumlah,sisa_jumlah,harga_beli,tgl_kedaluwarsa)
      VALUES(v_in,v_product,v_quantity,v_quantity,(v_item->>'price')::numeric,(v_item->>'expiry')::date);
      UPDATE public.barang SET stok_saat_ini=stok_saat_ini+v_quantity WHERE id_barang=v_product RETURNING stok_saat_ini INTO v_current;
      INSERT INTO public.kartu_stok(id_barang,waktu,jenis,referensi,jumlah,saldo,keterangan,id_pengguna)
      VALUES(v_product,(current_date-(7-v_idx))::timestamp + interval '09:00', 'masuk',v_trans,v_quantity,v_current,'barang masuk',v_actor);
    END LOOP;
  END LOOP;

  -- Outgoing transactions; batch balances reduce exactly with stock.
  v_outgoing := '[
    {"label":"Booth Utama","days":2,"rows":[["KMS-001",100],["KMS-002",80],["BHN-004",30],["ESK-001",5]]},
    {"label":"Operasional Harian","days":1,"rows":[["KMS-003",120],["BHN-001",10],["BHN-002",6],["TPG-001",8]]},
    {"label":"Outlet Event","days":0,"rows":[["SNK-001",20],["ESK-002",6],["BHN-003",15],["TPG-002",4]]}
  ]'::jsonb;

  v_idx := 0;
  FOR v_item IN SELECT value FROM jsonb_array_elements(v_outgoing) LOOP
    v_idx := v_idx + 1;
    v_actor := CASE v_idx WHEN 1 THEN v_fitri WHEN 2 THEN v_pandu ELSE v_haemin END;
    v_trans := 'OUT-' || to_char(current_date-(v_item->>'days')::int,'YYYYMMDD') || '-' || lpad(v_idx::text,3,'0');
    INSERT INTO public.outbound(no_transaksi,tanggal,tujuan,catatan,id_pengguna)
    VALUES(v_trans,current_date-(v_item->>'days')::int,v_item->>'label','Pemakaian operasional',v_actor)
    RETURNING id_outbound INTO v_out;
    FOR v_product, v_quantity IN
      SELECT b.id_barang, (j.value->>1)::numeric
      FROM jsonb_array_elements(v_item->'rows') j
      JOIN public.barang b ON b.kode_barang=(j.value->>0)
    LOOP
      SELECT id_inbound_detail INTO v_batch FROM public.inbound_detail WHERE id_barang=v_product ORDER BY id_inbound_detail LIMIT 1;
      UPDATE public.inbound_detail SET sisa_jumlah=sisa_jumlah-v_quantity WHERE id_inbound_detail=v_batch AND sisa_jumlah>=v_quantity;
      IF NOT FOUND THEN RAISE EXCEPTION 'Insufficient batch qty for %',v_product; END IF;
      UPDATE public.barang SET stok_saat_ini=stok_saat_ini-v_quantity WHERE id_barang=v_product AND stok_saat_ini>=v_quantity RETURNING stok_saat_ini INTO v_current;
      IF NOT FOUND THEN RAISE EXCEPTION 'Insufficient stock for %',v_product; END IF;
      INSERT INTO public.outbound_detail(id_outbound,id_barang,id_inbound_detail,jumlah) VALUES(v_out,v_product,v_batch,v_quantity);
      INSERT INTO public.kartu_stok(id_barang,waktu,jenis,referensi,jumlah,saldo,keterangan,id_pengguna)
      VALUES(v_product,(current_date-(v_item->>'days')::int)::timestamp + interval '14:00','keluar',v_trans,-v_quantity,v_current,'barang keluar',v_actor);
    END LOOP;
  END LOOP;

  -- Retur ke supplier dicatat terpisah dan mengurangi batch, stok, serta kartu stok.
  SELECT id_supplier INTO v_supplier FROM public.supplier WHERE nama_supplier='Distributor Bahan Minuman' LIMIT 1;
  SELECT id_barang INTO v_product FROM public.barang WHERE kode_barang='BHN-003';
  SELECT id_inbound_detail INTO v_batch FROM public.inbound_detail WHERE id_barang=v_product ORDER BY id_inbound_detail LIMIT 1;
  INSERT INTO public.retur_supplier(no_transaksi,tanggal,id_supplier,alasan,id_pengguna)
  VALUES('RET-'||to_char(current_date,'YYYYMMDD')||'-001',current_date,v_supplier,'Kemasan botol penyok',v_pandu) RETURNING id_retur INTO v_in;
  INSERT INTO public.retur_supplier_detail(id_retur,id_barang,jumlah) VALUES(v_in,v_product,2);
  UPDATE public.inbound_detail SET sisa_jumlah=sisa_jumlah-2 WHERE id_inbound_detail=v_batch AND sisa_jumlah>=2;
  IF NOT FOUND THEN RAISE EXCEPTION 'Batch retur tidak cukup'; END IF;
  UPDATE public.barang SET stok_saat_ini=stok_saat_ini-2 WHERE id_barang=v_product AND stok_saat_ini>=2 RETURNING stok_saat_ini INTO v_current;
  IF NOT FOUND THEN RAISE EXCEPTION 'Stok retur tidak cukup'; END IF;
  INSERT INTO public.kartu_stok(id_barang,jenis,referensi,jumlah,saldo,keterangan,id_pengguna)
  VALUES(v_product,'keluar','RET-'||to_char(current_date,'YYYYMMDD')||'-001',-2,v_current,'Retur supplier: kemasan penyok',v_pandu);

  -- Opname states: approved/rejected/pending. Approved row has zero adjustment, preserving ledger invariants.
  FOR v_idx IN 1..3 LOOP
    v_actor := CASE v_idx WHEN 1 THEN v_haemin WHEN 2 THEN v_fitri ELSE v_pandu END;
    v_trans := 'OP-' || to_char(current_date-(3-v_idx),'YYYYMMDD') || '-' || lpad(v_idx::text,3,'0');
    INSERT INTO public.stock_opname(no_transaksi,tanggal,status,catatan,id_pengguna,id_penyetuju,tgl_persetujuan,catatan_penyetuju)
    VALUES(v_trans,current_date-(3-v_idx),CASE v_idx WHEN 1 THEN 'disetujui' WHEN 2 THEN 'ditolak' ELSE 'menunggu' END,
    'Pemeriksaan stok berkala',v_actor,CASE WHEN v_idx=3 THEN NULL ELSE v_nita END,
    CASE WHEN v_idx=3 THEN NULL ELSE now() END,
    CASE v_idx WHEN 1 THEN 'Sesuai stok sistem' WHEN 2 THEN 'Perlu hitung ulang' ELSE NULL END)
    RETURNING id_opname INTO v_op;
    SELECT id_barang,stok_saat_ini INTO v_product,v_current FROM public.barang WHERE kode_barang=CASE v_idx WHEN 1 THEN 'BHN-004' WHEN 2 THEN 'KMS-001' ELSE 'TPG-002' END;
    INSERT INTO public.stock_opname_detail(id_opname,id_barang,stok_sistem,stok_fisik,selisih,alasan)
    VALUES(v_op,v_product,v_current,v_current + CASE WHEN v_idx=2 THEN -2 WHEN v_idx=3 THEN -1 ELSE 0 END,
      CASE WHEN v_idx=2 THEN -2 WHEN v_idx=3 THEN -1 ELSE 0 END,
      CASE WHEN v_idx=1 THEN NULL WHEN v_idx=2 THEN 'Terdapat 2 cup rusak' ELSE 'Perlu penghitungan ulang' END);
  END LOOP;
END;
$seed$;
COMMIT;
