/**
 * Provision two accounts after data reset. Uses the ADMIN API, never the browser.
 * Set environment variables; do not put passwords into repository files.
 * Can rerun safely when both Auth and profile already exist.
 * Note: this does not delete legacy Supabase Auth users automatically.
 */
import { createClient } from '@supabase/supabase-js';

const required = ['NEXT_PUBLIC_SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY', 'WAREHOUSE_ADMIN_EMAIL', 'WAREHOUSE_ADMIN_PASSWORD', 'WAREHOUSE_STAFF_EMAIL', 'WAREHOUSE_STAFF_PASSWORD'];
const missing = required.filter((name) => !process.env[name]);
if (missing.length) throw new Error(`Variabel lingkungan belum lengkap: ${missing.join(', ')}`);
if (process.env.CONFIRM_CREATE_WAREHOUSE_ACCOUNTS !== 'YES') throw new Error('Set CONFIRM_CREATE_WAREHOUSE_ACCOUNTS=YES untuk menjalankan pembuatan akun.');
const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY, { auth: { autoRefreshToken: false, persistSession: false } });
const accounts = [
  { email: process.env.WAREHOUSE_ADMIN_EMAIL, password: process.env.WAREHOUSE_ADMIN_PASSWORD, username: process.env.WAREHOUSE_ADMIN_USERNAME || 'admin', nama_lengkap: process.env.WAREHOUSE_ADMIN_NAME || 'Administrator Kedai Nita', peran: 'admin' },
  { email: process.env.WAREHOUSE_STAFF_EMAIL, password: process.env.WAREHOUSE_STAFF_PASSWORD, username: process.env.WAREHOUSE_STAFF_USERNAME || 'petugas', nama_lengkap: process.env.WAREHOUSE_STAFF_NAME || 'Petugas Gudang', peran: 'petugas' },
];
if (accounts[0].email.toLowerCase() === accounts[1].email.toLowerCase()) throw new Error('Email admin dan petugas harus berbeda.');
if (accounts[0].username === accounts[1].username) throw new Error('Username harus berbeda.');
for (const a of accounts) if (a.password.length < 12) throw new Error(`Password untuk ${a.username} minimal 12 karakter.`);
for (const account of accounts) {
  // Avoid resetting existing credentials or hijacking existing auth users.
  const { data: created, error: createError } = await supabase.auth.admin.createUser({ email: account.email, password: account.password, email_confirm: true });
  if (createError || !created?.user) {
    throw new Error(`Tidak bisa membuat akun Auth ${account.username}: ${createError?.message ?? 'unknown error'}. Gunakan email baru jika email lama masih ada di Authentication.`);
  }
  const { error: profileError } = await supabase.from('pengguna').insert({ auth_id: created.user.id, username: account.username, nama_lengkap: account.nama_lengkap, peran: account.peran, aktif: true });
  if (profileError) {
    const { error: rollbackError } = await supabase.auth.admin.deleteUser(created.user.id);
    throw new Error(`Profil ${account.username} gagal: ${profileError.message}${rollbackError ? '; rollback Auth juga gagal: ' + rollbackError.message : '; akun Auth dibatalkan'}`);
  }
  console.log(`Berhasil: ${account.username} (${account.peran}) — ${account.email}`);
}
console.log('Selesai. Simpan kredensial secara aman, lalu hapus variabel password dari terminal.');
