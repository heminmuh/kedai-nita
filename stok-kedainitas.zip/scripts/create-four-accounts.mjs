/** Jalankan hanya dengan service role server; akun existing tidak akan diubah. */
import { createClient } from '@supabase/supabase-js';
const specs = [
  { username:'nita', nama_lengkap:'Nita', peran:'admin', prefix:'NITA' },
  { username:'haemin', nama_lengkap:'Haemin', peran:'petugas', prefix:'HAEMIN' },
  { username:'fitri', nama_lengkap:'Fitri', peran:'petugas', prefix:'FITRI' },
  { username:'pandu', nama_lengkap:'Pandu', peran:'petugas', prefix:'PANDU' }
];
const vars = ['NEXT_PUBLIC_SUPABASE_URL','SUPABASE_SERVICE_ROLE_KEY',...specs.flatMap(s=>[`${s.prefix}_EMAIL`,`${s.prefix}_PASSWORD`])];
const missing = vars.filter(k=>!process.env[k]);
if(missing.length) throw Error('Variabel belum lengkap: '+missing.join(', '));
if(process.env.CONFIRM_CREATE_WAREHOUSE_ACCOUNTS!=='YES') throw Error('Set CONFIRM_CREATE_WAREHOUSE_ACCOUNTS=YES');
const accounts=specs.map(s=>({...s,email:process.env[`${s.prefix}_EMAIL`].trim().toLowerCase(),password:process.env[`${s.prefix}_PASSWORD`]}));
if(new Set(accounts.map(a=>a.email)).size!==4) throw Error('Email akun harus berbeda');
if(accounts.some(a=>a.password.length<12)) throw Error('Password minimal 12 karakter untuk setiap akun');
const admin=createClient(process.env.NEXT_PUBLIC_SUPABASE_URL,process.env.SUPABASE_SERVICE_ROLE_KEY,{auth:{persistSession:false,autoRefreshToken:false}});
const {data:profiles,error:profError}=await admin.from('pengguna').select('username');
if(profError) throw Error(profError.message);
const existing=new Set((profiles||[]).map(p=>p.username));
for(const a of accounts){
 if(existing.has(a.username)) throw Error('Profil sudah ada: '+a.username+'; proses dihentikan agar tidak menduplikasi akun');
}
for(const a of accounts){
 const {data,error}=await admin.auth.admin.createUser({email:a.email,password:a.password,email_confirm:true});
 if(error||!data?.user) throw Error(`Gagal membuat ${a.username}: ${error?.message||'unknown'}. Cek apakah email sudah ada di Auth.`);
 const {error:profileError}=await admin.from('pengguna').insert({auth_id:data.user.id,nama_lengkap:a.nama_lengkap,username:a.username,peran:a.peran,aktif:true});
 if(profileError){const {error:rollback}=await admin.auth.admin.deleteUser(data.user.id);throw Error(`Profil ${a.username} gagal: ${profileError.message}; rollback: ${rollback?.message||'berhasil'}`);}
 console.log(`Dibuat: ${a.username} (${a.peran})`);
}
