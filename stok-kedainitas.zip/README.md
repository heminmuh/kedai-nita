<div align="center">

# KEDAI NITA'S
### Sistem Informasi Manajemen Stok Gudang

**RANCANG BANGUN SISTEM INFORMASI MANAJEMEN STOK GUDANG _INBOUND & OUTBOUND GOODS_ BERBASIS _WEB_ PADA KEDAI NITA'S REMBANG, JAWA TENGAH**

**Proyek Capstone — Universitas Terbuka | Kelompok B**

![Next.js](https://img.shields.io/badge/Next.js-15-black?logo=nextdotjs) ![React](https://img.shields.io/badge/React-19-149eca?logo=react) ![TypeScript](https://img.shields.io/badge/TypeScript-5-3178c6?logo=typescript) ![Supabase](https://img.shields.io/badge/Supabase-Database%20%26%20Auth-3ecf8e?logo=supabase) ![Status](https://img.shields.io/badge/Status-Pengembangan-6834A6)

_Aplikasi berbasis web untuk mendukung pencatatan, pemantauan, dan pengendalian persediaan barang di Kedai Nita's._

</div>

---

## 📖 Tentang Proyek

Proyek capstone ini mengembangkan **sistem informasi manajemen stok gudang berbasis web** untuk Kedai Nita's yang berlokasi di **Rembang, Jawa Tengah**. Sistem dirancang untuk membantu proses **penerimaan barang (_inbound goods_)**, **pengeluaran barang (_outbound goods_)**, pemantauan ketersediaan stok, serta pencatatan aktivitas gudang agar lebih terstruktur dan mudah ditelusuri.

Aplikasi memiliki dua peran utama: **Admin/Owner** yang melakukan pengawasan dan pengelolaan data, serta **Petugas Gudang** yang menjalankan kegiatan operasional. Riwayat transaksi dicatat dalam kartu stok, sedangkan koreksi selisih stok dilakukan melalui proses stock opname yang membutuhkan persetujuan admin.

> **Catatan:** Proyek ini merupakan aplikasi capstone. Data yang digunakan untuk pengujian merupakan data simulasi dan tidak boleh diperlakukan sebagai transaksi operasional aktual tanpa verifikasi.

## 🎯 Tujuan

1. Mendigitalisasi pengelolaan data barang, supplier, dan lokasi rak.
2. Mempermudah pencatatan barang masuk, barang keluar, dan retur ke supplier.
3. Menyediakan monitoring stok dan indikator stok minimum.
4. Mendokumentasikan mutasi stok dalam kartu stok yang dapat ditelusuri.
5. Mendukung pengajuan serta persetujuan stock opname berdasarkan hak akses pengguna.
6. Menyajikan laporan dan ekspor data untuk membantu proses pengawasan persediaan.

## ✨ Fitur Utama

| Modul | Deskripsi |
|---|---|
| **Overview Dashboard** | Ringkasan produk, stok menipis, transaksi, dan grafik aktivitas gudang. |
| **Master Barang** | Menambah, melihat, mengubah, dan menghapus data barang sesuai aturan relasi data. |
| **Supplier** | Mengelola informasi supplier. |
| **Lokasi Rak** | Mengelola rak serta melihat daftar barang yang ditempatkan pada setiap rak. |
| **Barang Masuk (Inbound)** | Mencatat penerimaan barang, jumlah, harga beli, supplier, dan foto bukti. |
| **Barang Keluar (Outbound)** | Mencatat pengeluaran barang beserta detail item dan foto bukti. |
| **Retur Barang** | Mencatat pengembalian barang ke supplier dan pengaruhnya terhadap stok. |
| **Monitoring Stok** | Memantau stok terkini, minimum stok, status, dan lokasi rak; dilengkapi pencarian. |
| **Stock Opname** | Petugas mengajukan hasil perhitungan fisik; admin menyetujui atau menolak dengan alasan. |
| **Kartu Stok** | Riwayat mutasi barang masuk, keluar, dan penyesuaian stok dengan filter. |
| **Laporan** | Menampilkan posisi stok, perbandingan harga pembelian, pencarian, dan ekspor CSV. |
| **Manajemen Pengguna** | Pengelolaan akun dan peran pengguna melalui Supabase Authentication. |

**Fitur antarmuka:** desain responsif, sidebar yang dapat diperkecil, modal formulir, validasi input wajib, dialog SweetAlert2, filter tanggal, serta pilihan tema terang/gelap.

## 👥 Hak Akses Pengguna

| Akses | Admin / Owner | Petugas Gudang |
|---|:---:|:---:|
| Overview | ✅ | ✅ |
| Master barang, supplier, dan rak | ✅ | — |
| Pencatatan inbound dan outbound | ✅ | ✅ |
| Retur barang | ✅ | ✅ |
| Monitoring dan kartu stok | ✅ | ✅ |
| Mengajukan stock opname | — | ✅ |
| Meninjau / menyetujui stock opname | ✅ | — |
| Laporan dan ekspor data | ✅ | — |
| Manajemen akun | ✅ | — |

_Pembatasan antarmuka juga perlu diselaraskan dengan otorisasi di server dan kebijakan Row Level Security (RLS) Supabase._

## 🔄 Alur Kerja Sistem

```mermaid
flowchart TD
    A[Login pengguna] --> B{Peran pengguna}
    B -->|Admin / Owner| C[Kelola master data dan pantau laporan]
    B -->|Petugas Gudang| D[Catat aktivitas gudang]
    D --> E[Barang masuk / barang keluar / retur]
    E --> F[Monitoring stok dan kartu stok]
    D --> G[Ajukan stock opname]
    G --> H{Keputusan admin}
    H -->|Disetujui| I[Penyesuaian stok dan pencatatan mutasi]
    H -->|Ditolak| J[Stok tidak berubah; alasan dicatat]
    I --> F
```

> Stock opname merupakan proses pencocokan stok fisik dan stok sistem, **bukan** transaksi retur. Koreksi stok hanya diproses setelah disetujui oleh admin.

## 🛠️ Teknologi

| Teknologi | Penggunaan |
|---|---|
| [Next.js 15](https://nextjs.org/) | Framework aplikasi web (App Router). |
| [React 19](https://react.dev/) | Pembuatan komponen antarmuka. |
| [TypeScript](https://www.typescriptlang.org/) | Pengembangan dengan tipe data statis. |
| [Supabase](https://supabase.com/) | PostgreSQL, autentikasi, dan penyimpanan foto bukti. |
| [Lucide React](https://lucide.dev/) | Ikon antarmuka. |
| [SweetAlert2](https://sweetalert2.github.io/) | Dialog konfirmasi dan notifikasi. |
| CSS | Styling responsif dengan warna identitas ungu dan lavender. |

### Identitas Visual

- **Primary Purple:** `#6834A6`
- **Sweet Lavender:** `#9872D5`
- **Soft Lilac:** `#EEE5FA`

## 📂 Struktur Proyek

```text
kedai-nitas-nextjs/
├── public/                    # Aset statis
├── scripts/                   # Skrip persiapan akun pengujian
├── src/
│   ├── app/                   # Halaman App Router dan API routes
│   │   ├── (app)/             # Halaman dashboard dan modul gudang
│   │   ├── login/             # Halaman autentikasi
│   │   └── api/               # Endpoint aplikasi, termasuk ekspor
│   ├── components/            # Komponen UI, tabel, modal, dan formulir
│   ├── lib/                   # Aksi server, query, auth, dan utilitas
│   └── styles/                # Stylesheet global
├── supabase/
│   ├── migrations/            # Skema dan perubahan database
│   ├── reset/                 # Skrip reset data (destruktif)
│   └── seeds/                 # Data pengujian opsional
├── .env.example               # Contoh konfigurasi lingkungan
└── package.json
```

## 🚀 Instalasi dan Menjalankan Aplikasi

### Prasyarat

- Node.js versi modern yang kompatibel dengan Next.js 15 (disarankan Node.js 20 atau 22).
- npm.
- Project Supabase dengan akses untuk menjalankan migrasi SQL.

### 1. Clone repository

```bash
git clone <URL-REPOSITORY-GITHUB>
cd kedai-nitas-nextjs
```

Ganti `<URL-REPOSITORY-GITHUB>` dengan alamat repo setelah diunggah ke GitHub.

### 2. Instal dependensi

```bash
npm install
```

### 3. Atur environment

Salin `.env.example` menjadi `.env.local`, lalu isi sesuai project Supabase:

```env
NEXT_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_OR_PUBLISHABLE_KEY
SUPABASE_SERVICE_ROLE_KEY=YOUR_SERVICE_ROLE_KEY
```

**Keamanan:** `SUPABASE_SERVICE_ROLE_KEY` bersifat rahasia dan hanya boleh digunakan pada server. Jangan memasukkan `.env.local`, kredensial, atau password ke GitHub.

### 4. Siapkan database

Jalankan SQL pada direktori `supabase/migrations/` melalui Supabase SQL Editor sesuai urutan nomor migrasi, dimulai dari `001_init.sql` hingga migrasi terbaru yang tersedia. Pastikan pengaturan RLS dan bucket Storage yang digunakan aplikasi telah dikonfigurasi.

> Jangan menjalankan file pada `supabase/reset/` di database yang berisi data penting. Skrip reset akan menghapus data operasional.

### 5. Siapkan akun pengguna

Akun dapat dibuat melalui mekanisme admin aplikasi atau skrip persiapan akun pada `scripts/`. Untuk pengujian capstone, pengguna yang direncanakan adalah **nita** (Admin) serta **haemin**, **fitri**, dan **pandu** (Petugas Gudang).

File `README-SETUP-4-AKUN.md` memuat informasi persiapan akun. Email dan password perlu dikonfigurasi secara privat; **tidak disertakan di repository**.

### 6. Jalankan aplikasi

```bash
npm run dev
```

Buka **http://localhost:3000** di browser.

Untuk pemeriksaan tipe dan build:

```bash
npm run typecheck
npm run build
npm run start
```

> Ketersediaan fitur dan keberhasilan build bergantung pada versi source, migrasi, dan konfigurasi Supabase yang digunakan. Dokumentasi ini tidak menyatakan bahwa pengujian produksi telah selesai.

## 🧪 Skenario Pengujian Capstone

| No. | Skenario | Hasil yang diharapkan |
|---|---|---|
| 1 | Login sebagai Admin | Masuk ke dashboard dengan menu sesuai peran admin. |
| 2 | Login sebagai Petugas | Hanya melihat menu operasional yang diizinkan. |
| 3 | Mencatat Barang Masuk | Stok bertambah dan tercatat pada kartu stok. |
| 4 | Mencatat Barang Keluar | Stok berkurang dan riwayat transaksi tercatat. |
| 5 | Membuat Retur Supplier | Retur tercatat dan stok disesuaikan. |
| 6 | Mengajukan Stock Opname | Pengajuan tampil dengan status menunggu. |
| 7 | Admin menyetujui Stock Opname | Stok disesuaikan dan mutasi tercatat. |
| 8 | Admin menolak Stock Opname | Stok tidak berubah; alasan keputusan terlihat. |
| 9 | Melakukan pencarian dan filter tanggal | Data yang ditampilkan sesuai kriteria. |
| 10 | Mengunduh laporan CSV | File unduhan berisi data yang diizinkan untuk akun tersebut. |

Tabel di atas merupakan **rencana skenario pengujian**, bukan pernyataan bahwa semuanya telah lolos uji.

## 📸 Dokumentasi Tampilan

Tambahkan tangkapan layar aplikasi ke folder `docs/screenshots/`, lalu aktifkan bagian berikut setelah gambarnya tersedia:

```md
![Halaman Login](docs/screenshots/login.png)
![Overview Dashboard](docs/screenshots/dashboard.png)
![Monitoring Stok](docs/screenshots/monitoring-stok.png)
![Stock Opname](docs/screenshots/stock-opname.png)
```

## 🎓 Tim Pengembang — Kelompok B

**Capstone Universitas Terbuka**

| Nama Mahasiswa | NIM |
|---|---|
| **Nita Widiastuti** | 052152038 |
| **Yahya Muhaemin** | 051796845 |
| **Fitri Setiyani** | 050405459 |
| **Pandu Putra Setiaji** | 050056485 |

### Judul Capstone

**RANCANG BANGUN SISTEM INFORMASI MANAJEMEN STOK GUDANG _INBOUND & OUTBOUND GOODS_ BERBASIS _WEB_ PADA KEDAI NITA'S REMBANG, JAWA TENGAH**

---

<div align="center">

**Dikembangkan sebagai proyek capstone Kelompok B — Universitas Terbuka.**

_Kedai Nita's Warehouse Management System_

</div>
